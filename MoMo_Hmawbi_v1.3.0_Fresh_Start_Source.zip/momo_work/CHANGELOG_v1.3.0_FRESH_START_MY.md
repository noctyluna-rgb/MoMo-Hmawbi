# MoMo(Hmawbi) v1.3.0 — Fresh Start

- User အတည်ပြုချက်အရ ယခင် local အရောင်းစာရင်း database ကို ပထမဆုံး launch တွင် တစ်ကြိမ်တည်း ဖျက်မည်။
- Customer Map pins၊ custom SKU၊ price overrides၊ product photo references၊ manual amounts နှင့် app-private photo/cache files များကိုလည်း ရှင်းလင်းမည်။
- Cleanup ပြီးနောက် marker ရေးထားသဖြင့် နောက်ထပ် launch များတွင် အသစ်ထည့်သည့် Data များကို မဖျက်ပါ။
- applicationId ကို မပြောင်းထားပါ: `com.momo.mahwbi`။
- versionName: `1.3.0`; versionCode: `36`။
- ဤပြင်ဆင်ချက်သည် local app data ကိုသာ သက်ရောက်ပြီး cloud data ကို မဖျက်ပါ။
- Build/device test မလုပ်ရသေးပါ။
