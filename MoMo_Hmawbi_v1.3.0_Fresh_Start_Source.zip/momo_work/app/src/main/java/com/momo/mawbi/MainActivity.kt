package com.momo.mahwbi

import android.net.Uri
import android.widget.ImageView
import android.content.Intent
import android.content.Context
import android.location.LocationManager
import android.location.Location
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polygon
import kotlin.math.cos
import kotlin.math.sin
import android.os.Bundle
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.launch
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.TemporalAdjusters
import java.time.format.DateTimeFormatter
import java.util.Calendar
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import androidx.room.withTransaction

private enum class Period(val label: String) { DAILY("Daily"), WEEKLY("Weekly"), MONTHLY("Monthly") }
private enum class Page(val label: String, val icon: String) {
    DASHBOARD("Dashboard", "⌂"), ENTRY("Daily Sales", "＋"), REPORTS("Sales Reports", "▥"),
    PRODUCTS("Product & Price", "▣"), MAP("Customer Map", "⌖"), OCR("Receipt OCR", "▤"), HISTORY("Sales History", "◷"), SETTINGS("Settings", "⚙")
}
// Clean White Blue theme palette
private val Navy = Color(0xFF071B59)       // deep glossy jelly dashboard background
private val Panel = Color(0xFFEAF8FF)      // luminous jelly surface
private val Panel2 = Color(0xFFD9ECFF)     // selected / secondary surfaces
private val Accent = Color(0xFF1769C2)     // primary blue
private val DashboardBlue = Color(0xFF102F63) // deep blue dashboard bar
private val DailyBright = Color(0xFF087FE5)
private val MonthlyBright = Color(0xFF6941C6)
private val Muted = Color(0xFF52718F)      // secondary text
private val Ink = Color(0xFF172B4D)        // main text
private val LightGreen = Color(0xFFE4F5E9)
private val LightGreenInk = Color(0xFF21643A)
private val LightRed = Color(0xFFFCE8E8)
private val LightRedInk = Color(0xFF9B2C2C)
private const val MONTHLY_TARGET_MMK = 170_000_000L // 1,700 သိန်း
private val CATEGORY_MONTHLY_TARGETS = mapOf(
    Category.SANITARY to 30_600_000L,
    Category.BABY_DIAPER to 68_000_000L,
    Category.ADULT to 27_200_000L,
    Category.WET_TISSUE to 5_100_000L,
    Category.DRY_TISSUE to 39_100_000L
)
private val SHEETS_CATEGORY_ORDER = listOf(
    Category.SANITARY,
    Category.BABY_DIAPER,
    Category.ADULT,
    Category.WET_TISSUE,
    Category.DRY_TISSUE
)

private fun sheetsActualCopyText(rows: List<SaleLineEntity>): String =
    SHEETS_CATEGORY_ORDER.joinToString("\n") { category ->
        rows.filter { it.category == category.name }.sumOf { it.amountMmk }.toString()
    }

private fun Category.targetFor(period: Period): Long {
    val monthly = CATEGORY_MONTHLY_TARGETS[this] ?: 0L
    return when (period) {
        Period.DAILY -> (monthly * 2L) / 25L // Daily target ratio from the supplied report (8% of monthly target)
        Period.WEEKLY -> monthly / 4L
        Period.MONTHLY -> monthly
    }
}
private fun Long.asDate(): LocalDate = Instant.ofEpochMilli(this).atZone(ZoneId.systemDefault()).toLocalDate()
private fun Long.mmk(): String = "% ,d ကျပ်".replace(" ", "").format(this)
private fun SaleLineEntity.inPeriod(period: Period, today: LocalDate): Boolean {
    val d = createdAt.asDate()
    return when (period) {
        Period.DAILY -> d == today
        Period.WEEKLY -> !d.isBefore(today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))) && !d.isAfter(today)
        Period.MONTHLY -> d.year == today.year && d.month == today.month
    }
}

/**
 * One-time clean start for the 1.3.0 release.
 * The user explicitly chose to discard all data from the previous app version.
 * The marker is stored after cleanup so normal future launches never wipe new data.
 */
private fun resetLegacyLocalDataForFreshStart(context: Context): Boolean {
    val markerName = "momo_fresh_start_1_3_0.done"
    val marker = File(context.filesDir, markerName)
    if (marker.exists()) return false

    // Release persisted product-photo URI grants before removing their preferences.
    val photoPrefs = context.getSharedPreferences("momo_product_photos", Context.MODE_PRIVATE)
    photoPrefs.all.values.filterIsInstance<String>().forEach { raw ->
        runCatching {
            val uri = Uri.parse(raw)
            if (uri.scheme == "content") {
                context.contentResolver.releasePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
        }
    }

    // Clear every local preference store used by this project.
    listOf(
        "momo_price_master",
        "momo_sku_master",
        "momo_product_photos",
        "momo_customer_map",
        "momo_manual_amounts"
    ).forEach { name ->
        check(context.getSharedPreferences(name, Context.MODE_PRIVATE).edit().clear().commit()) {
            "Unable to clear local preferences: $name"
        }
    }

    // Remove the old Room database and app-private files (including stored product photos).
    context.deleteDatabase("momo_sales.db")
    fun clearDirectory(directory: File?) {
        directory?.listFiles()?.forEach { child ->
            if (child.isDirectory) clearDirectory(child)
            child.delete()
        }
    }
    clearDirectory(context.filesDir)
    clearDirectory(context.cacheDir)
    clearDirectory(context.externalCacheDir)

    check(marker.createNewFile()) { "Unable to create fresh-start marker" }
    marker.writeText("MoMo(Hmawbi) 1.3.0 fresh start completed")
    return true
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        resetLegacyLocalDataForFreshStart(applicationContext)
        window.statusBarColor = android.graphics.Color.rgb(23, 105, 170)
        window.decorView.systemUiVisibility = 0
        setContent { MoMoApp() }
    }
}

@Composable
@OptIn(ExperimentalMaterial3Api::class)
private fun MoMoApp() {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val dao = remember { MoMoDatabase.get(context).salesDao() }
    val scope = rememberCoroutineScope()
    val pricePrefs = remember { context.getSharedPreferences("momo_price_master", android.content.Context.MODE_PRIVATE) }
    val skuPrefs = remember { context.getSharedPreferences("momo_sku_master", android.content.Context.MODE_PRIVATE) }
    val productPhotoPrefs = remember { context.getSharedPreferences("momo_product_photos", android.content.Context.MODE_PRIVATE) }
    val productPhotos = remember {
        mutableStateMapOf<String, String>().apply {
            productPhotoPrefs.all.forEach { (key, value) ->
                if (value is String && value.isNotBlank()) put(key, value)
            }
        }
    }
    var notice by remember { mutableStateOf("") }
    var showDeveloperPopup by remember { mutableStateOf(false) }
    var customerName by remember { mutableStateOf("") }
    var customerLat by remember { mutableStateOf("") }
    var customerLon by remember { mutableStateOf("") }
    val customerPins = remember { mutableStateListOf<Triple<String, Double, Double>>().apply {
        runCatching {
            val arr = JSONArray(context.getSharedPreferences("momo_customer_map", android.content.Context.MODE_PRIVATE).getString("pins", "[]"))
            for (i in 0 until arr.length()) { val o = arr.getJSONObject(i); add(Triple(o.optString("name"), o.optDouble("lat"), o.optDouble("lon"))) }
        }
    } }
    var mapView by remember { mutableStateOf<MapView?>(null) }
    val locationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        if (grants.values.any { it }) {
            val lm = context.getSystemService(android.content.Context.LOCATION_SERVICE) as LocationManager
            val loc = runCatching { lm.getLastKnownLocation(LocationManager.GPS_PROVIDER) ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER) }.getOrNull()
            if (loc != null) mapView?.controller?.animateTo(GeoPoint(loc.latitude, loc.longitude)) else notice = "GPS တည်နေရာ မရသေးပါ။ Location ဖွင့်ထားပါ။"
        } else notice = "GPS အသုံးပြုခွင့် မပေးထားပါ။"
    }
    fun persistCustomerPins() {
        val arr = JSONArray(); customerPins.forEach { (n, la, lo) -> arr.put(JSONObject().put("name", n).put("lat", la).put("lon", lo)) }
        context.getSharedPreferences("momo_customer_map", android.content.Context.MODE_PRIVATE).edit().putString("pins", arr.toString()).apply()
    }
    var photoTargetSku by remember { mutableStateOf("") }
    val productPhotoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null && photoTargetSku.isNotBlank()) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            productPhotos[photoTargetSku] = uri.toString()
            productPhotoPrefs.edit().putString(photoTargetSku, uri.toString()).apply()
            notice = "${photoTargetSku} ပုံ သိမ်းပြီးပါပြီ"
        }
    }
    val skuList = remember {
        mutableStateListOf<Sku>().apply {
            addAll(SkuMaster.all)
            val raw = skuPrefs.getString("custom_skus", null)
            if (!raw.isNullOrBlank()) {
                runCatching {
                    val arr = JSONArray(raw)
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        val name = o.optString("name").trim()
                        val category = runCatching { Category.valueOf(o.optString("category")) }.getOrNull()
                        if (name.isNotBlank() && category != null && none { it.name.equals(name, true) }) {
                            add(Sku(name, category, o.optLong("price", 0L), o.optInt("bag", 1), o.optInt("carton", 1)))
                        }
                    }
                }
            }
        }
    }
    val priceOverrides = remember {
        mutableStateMapOf<String, Long>().apply {
            skuList.forEach { item ->
                val saved = pricePrefs.getLong(item.name, -1L)
                if (saved > 0L) put(item.name, saved)
            }
        }
    }
    fun currentPrice(item: Sku): Long = priceOverrides[item.name] ?: item.pricePerPack
    fun bundledPhoto(item: Sku): Int {
        val key = item.name.lowercase().replace(" ", "_")
        val resourceName = when (item.name.lowercase()) {
            "pull သေး" -> "sku_pull_small"
            "pull 1 nb", "nb" -> "sku_nb"
            "lady pants" -> "sku_lady_pants"
            "daily718", "blue718" -> "sku_blue718"
            "baby mother pad" -> "sku_baby_mother_pad"
            "wasuka mini" -> "sku_wasuka_mini"
            "daily728", "blue728" -> "sku_blue728"
            "dima300", "dima" -> "sku_dima300"
            "under pad" -> "sku_under_pad"
            "comfree pull" -> "sku_comfree_l"
            "royal baby", "pull gyi" -> "sku_royal_baby"
            "blue 423", "blue423" -> "sku_blue423"
            "comfree diaper xl" -> "sku_comfree_diaper_xl"
            "comfree diaper l" -> "sku_comfree_diaper_xl"
            else -> ""
        }
        return if (resourceName.isBlank()) 0 else context.resources.getIdentifier(resourceName, "drawable", context.packageName)
    }
    fun saveCustomSkus() {
        val arr = JSONArray()
        skuList.filter { custom -> SkuMaster.findByName(custom.name) == null }.forEach { item ->
            arr.put(JSONObject().put("name", item.name).put("category", item.category.name)
                .put("price", item.pricePerPack).put("bag", item.packsPerBag).put("carton", item.packsPerCarton))
        }
        skuPrefs.edit().putString("custom_skus", arr.toString()).apply()
    }
    val sales by dao.observeAll().collectAsStateWithLifecycle(initialValue = emptyList())
    val backupPrefs = listOf("momo_price_master", "momo_sku_master", "momo_customer_map", "momo_manual_amounts")
    val backupExporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.use { output ->
                    ZipOutputStream(output).use { zip ->
                        val root = JSONObject().put("format", "momo-hmawbi-backup-v2").put("createdAt", System.currentTimeMillis())
                        val rows = JSONArray()
                        sales.forEach { line -> rows.put(JSONObject().put("id", line.id).put("skuName", line.skuName).put("category", line.category).put("receiptQuantity", line.receiptQuantity).put("receiptUnit", line.receiptUnit).put("packQuantity", line.packQuantity).put("unitPriceMmk", line.unitPriceMmk).put("amountMmk", line.amountMmk).put("createdAt", line.createdAt)) }
                        root.put("sales", rows)
                        val prefsJson = JSONObject()
                        backupPrefs.forEach { prefName ->
                            val values = JSONObject()
                            context.getSharedPreferences(prefName, android.content.Context.MODE_PRIVATE).all.forEach { (key, value) ->
                                when (value) {
                                    is String -> values.put(key, JSONObject().put("type", "string").put("value", value))
                                    is Int -> values.put(key, JSONObject().put("type", "int").put("value", value))
                                    is Long -> values.put(key, JSONObject().put("type", "long").put("value", value))
                                    is Boolean -> values.put(key, JSONObject().put("type", "boolean").put("value", value))
                                    is Float -> values.put(key, JSONObject().put("type", "float").put("value", value.toDouble()))
                                    is Set<*> -> values.put(key, JSONObject().put("type", "stringSet").put("value", JSONArray(value.filterIsInstance<String>())))
                                }
                            }
                            prefsJson.put(prefName, values)
                        }
                        val photoValues = JSONObject()
                        productPhotos.toMap().entries.forEachIndexed { index, entry ->
                            val sku = entry.key
                            val rawUri = entry.value
                            runCatching {
                                val photoUri = Uri.parse(rawUri)
                                val bytes = if (photoUri.scheme == "file") File(photoUri.path!!).readBytes() else context.contentResolver.openInputStream(photoUri)?.use { it.readBytes() } ?: error("ဓာတ်ပုံဖတ်မရ: $sku")
                                val ext = when {
                                    bytes.size > 3 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xD8.toByte() -> "jpg"
                                    bytes.size > 8 && bytes[0] == 0x89.toByte() -> "png"
                                    else -> "img"
                                }
                                val entryName = "photos/photo_${index}.$ext"
                                zip.putNextEntry(ZipEntry(entryName)); zip.write(bytes); zip.closeEntry()
                                photoValues.put(sku, entryName)
                            }.onFailure { throw IllegalStateException("$sku ဓာတ်ပုံကို Backup မလုပ်နိုင်ပါ: ${it.message}") }
                        }
                        prefsJson.put("momo_product_photos", photoValues)
                        root.put("preferences", prefsJson)
                        zip.putNextEntry(ZipEntry("backup.json")); zip.write(root.toString().toByteArray(Charsets.UTF_8)); zip.closeEntry()
                    }
                } ?: error("ဖိုင်ရေးမရပါ")
            }.onSuccess { notice = "ဓာတ်ပုံဖိုင်များအပါအဝင် Backup ZIP သိမ်းပြီးပါပြီ။ ဖိုင်ကို လုံခြုံတဲ့နေရာမှာ ထပ်မံသိမ်းထားပါ။" }
             .onFailure { notice = "Backup မအောင်မြင်ပါ: ${it.message ?: "အမှားတစ်ခု ဖြစ်နေပါတယ်"}" }
        }
    }
    val backupImporter = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                val entries = linkedMapOf<String, ByteArray>()
                context.contentResolver.openInputStream(uri)?.use { input ->
                    ZipInputStream(input).use { zip ->
                        while (true) {
                            val entry = zip.nextEntry ?: break
                            if (!entry.isDirectory) {
                                require(entry.name.startsWith("photos/") || entry.name == "backup.json") { "Backup ထဲတွင် မသိသောဖိုင် ပါဝင်နေပါတယ်" }
                                require(!entry.name.contains("..")) { "Backup ဖိုင်လမ်းကြောင်း မမှန်ပါ" }
                                entries[entry.name] = zip.readBytes()
                            }
                            zip.closeEntry()
                        }
                    }
                } ?: error("ဖိုင်ဖတ်မရပါ")
                val raw = entries["backup.json"]?.toString(Charsets.UTF_8) ?: error("Backup ဖိုင်ထဲမှာ backup.json မတွေ့ပါ")
                val root = JSONObject(raw)
                require(root.optString("format") == "momo-hmawbi-backup-v2") { "ဒီ ZIP သည် Mo Mo Backup v2 မဟုတ်ပါ" }
                val rows = root.getJSONArray("sales")
                val restored = ArrayList<SaleLineEntity>(rows.length())
                for (i in 0 until rows.length()) {
                    val o = rows.getJSONObject(i)
                    restored.add(SaleLineEntity(id = 0, skuName = o.getString("skuName"), category = o.getString("category"), receiptQuantity = o.getInt("receiptQuantity"), receiptUnit = o.getString("receiptUnit"), packQuantity = o.getInt("packQuantity"), unitPriceMmk = o.getLong("unitPriceMmk"), amountMmk = o.getLong("amountMmk"), createdAt = o.getLong("createdAt")))
                }
                val prefsJson = root.getJSONObject("preferences")
                val photoValues = prefsJson.optJSONObject("momo_product_photos") ?: JSONObject()
                val photoDir = File(context.filesDir, "product_photos").apply { mkdirs() }
                val stagedPhotos = linkedMapOf<String, String>()
                val photoKeys = photoValues.keys()
                while (photoKeys.hasNext()) {
                    val sku = photoKeys.next(); val entryName = photoValues.getString(sku)
                    val bytes = entries[entryName] ?: error("ဓာတ်ပုံဖိုင် မပြည့်စုံပါ: $sku")
                    require(bytes.isNotEmpty() && bytes.size <= 15 * 1024 * 1024) { "ဓာတ်ပုံဖိုင် အရွယ်အစား မမှန်ပါ: $sku" }
                    val safeName = "photo_${sku.hashCode().toUInt().toString(16)}_${System.currentTimeMillis()}.img"
                    val target = File(photoDir, safeName)
                    target.writeBytes(bytes)
                    stagedPhotos[sku] = Uri.fromFile(target).toString()
                }
                // Validate all data before replacing anything; keep a rollback snapshot in memory.
                val db = MoMoDatabase.get(context)
                val oldRows = db.salesDao().getAll()
                val oldPrefs = backupPrefs.associateWith { context.getSharedPreferences(it, android.content.Context.MODE_PRIVATE).all.toMap() }
                val oldPhotos = productPhotoPrefs.all.toMap()
                try {
                    db.withTransaction {
                        db.salesDao().deleteAll()
                        if (restored.isNotEmpty()) db.salesDao().insertAll(restored)
                    }
                    backupPrefs.forEach { prefName ->
                        val editor = context.getSharedPreferences(prefName, android.content.Context.MODE_PRIVATE).edit().clear()
                        val values = prefsJson.optJSONObject(prefName) ?: JSONObject()
                        val keys = values.keys()
                        while (keys.hasNext()) {
                            val key = keys.next(); val item = values.getJSONObject(key); val value = item.opt("value")
                            when (item.optString("type")) {
                                "string" -> editor.putString(key, value as? String)
                                "int" -> editor.putInt(key, (value as Number).toInt())
                                "long" -> editor.putLong(key, (value as Number).toLong())
                                "boolean" -> editor.putBoolean(key, value as Boolean)
                                "float" -> editor.putFloat(key, (value as Number).toFloat())
                                "stringSet" -> { val a = item.getJSONArray("value"); editor.putStringSet(key, (0 until a.length()).map { a.getString(it) }.toSet()) }
                            }
                        }
                        check(editor.commit()) { "$prefName ဆက်တင် မသိမ်းနိုင်ပါ" }
                    }
                    val photoEditor = productPhotoPrefs.edit().clear()
                    stagedPhotos.forEach { (sku, path) -> photoEditor.putString(sku, path) }
                    check(photoEditor.commit()) { "ဓာတ်ပုံဆက်တင် မသိမ်းနိုင်ပါ" }
                    productPhotos.clear(); productPhotos.putAll(stagedPhotos)
                } catch (restoreError: Throwable) {
                    db.withTransaction { db.salesDao().deleteAll(); if (oldRows.isNotEmpty()) db.salesDao().insertAll(oldRows) }
                    oldPrefs.forEach { (prefName, values) ->
                        val editor = context.getSharedPreferences(prefName, android.content.Context.MODE_PRIVATE).edit().clear()
                        values.forEach { (key, value) -> when (value) {
                            is String -> editor.putString(key, value); is Int -> editor.putInt(key, value); is Long -> editor.putLong(key, value); is Boolean -> editor.putBoolean(key, value); is Float -> editor.putFloat(key, value); is Set<*> -> editor.putStringSet(key, value.filterIsInstance<String>().toSet())
                        } }
                        editor.commit()
                    }
                    val photoEditor = productPhotoPrefs.edit().clear(); oldPhotos.forEach { (key, value) -> if (value is String) photoEditor.putString(key, value) }; photoEditor.commit()
                    throw restoreError
                }
            }.onSuccess { notice = "Restore အောင်မြင်ပါပြီ။ အရောင်းစာရင်း၊ ဆက်တင်များနှင့် ဓာတ်ပုံဖိုင်များ ပြန်ရပါပြီ။ App ကို ပိတ်ပြီး ပြန်ဖွင့်ပါ။" }
             .onFailure { notice = "Restore မအောင်မြင်ပါ။ လက်ရှိဒေတာကို မူလအတိုင်း ပြန်ထားရန် ကြိုးစားပြီးပါပြီ။ အကြောင်းရင်း: ${it.message ?: "Backup ဖိုင်ကို စစ်ပါ"}" }
        }
    }
    val manualAmountPrefs = remember { context.getSharedPreferences("momo_manual_amounts", android.content.Context.MODE_PRIVATE) }
    val manualAmounts = remember { mutableStateMapOf<String, Long>().apply {
        runCatching { val obj = JSONObject(manualAmountPrefs.getString("daily_amounts", "{}") ?: "{}"); val it = obj.keys(); while (it.hasNext()) { val k = it.next(); put(k, obj.optLong(k)) } }
    } }
    var amountDate by remember { mutableStateOf(LocalDate.now()) }
    var amountText by remember { mutableStateOf("") }
    var amountPinEntry by remember { mutableStateOf("") }
    var amountUnlocked by remember { mutableStateOf(false) }
    var showAmountPinDialog by remember { mutableStateOf(false) }
    var showAmountDatePicker by remember { mutableStateOf(false) }
    fun saveManualAmount(date: LocalDate, amount: Long) {
        manualAmounts[date.toString()] = amount
        val obj = JSONObject(); manualAmounts.forEach { (key, value) -> obj.put(key, value) }
        manualAmountPrefs.edit().putString("daily_amounts", obj.toString()).apply()
    }
    var page by remember { mutableStateOf(Page.DASHBOARD) }
    val pageHistory = remember { mutableStateListOf<Page>() }
    fun navigateTo(target: Page) {
        if (target != page) pageHistory.add(page)
        page = target
    }
    fun navigateBack() {
        page = if (pageHistory.isNotEmpty()) pageHistory.removeAt(pageHistory.lastIndex) else Page.DASHBOARD
    }
    androidx.activity.compose.BackHandler(enabled = page != Page.DASHBOARD || pageHistory.isNotEmpty()) { navigateBack() }
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    var sku by remember { mutableStateOf(SkuMaster.all.first()) }
    var unit by remember { mutableStateOf(ReceiptUnit.PACK) }
    var qtyText by remember { mutableStateOf("1") }
    var skuMenu by remember { mutableStateOf(false) }
    var unitMenu by remember { mutableStateOf(false) }
    var editingSku by remember { mutableStateOf<Sku?>(null) }
    var editedPriceText by remember { mutableStateOf("") }
    var ownerPinEntry by remember { mutableStateOf("") }
    var showOwnerPinDialog by remember { mutableStateOf(false) }
    var ownerPriceUnlocked by remember { mutableStateOf(false) }
    var showAddSkuDialog by remember { mutableStateOf(false) }
    var newSkuName by remember { mutableStateOf("") }
    var newSkuCategory by remember { mutableStateOf(Category.BABY_DIAPER) }
    var newSkuPrice by remember { mutableStateOf("") }
    var newSkuBag by remember { mutableStateOf("1") }
    var newSkuCarton by remember { mutableStateOf("1") }
    var categoryMenu by remember { mutableStateOf(false) }
    var period by remember { mutableStateOf(Period.DAILY) }
    var ocrText by remember { mutableStateOf("ဘောင်ချာ Screenshot ကို Gallery မှ ရွေးချယ်ပါ။") }
    var loading by remember { mutableStateOf(false) }
    val ocrCandidates = remember { mutableStateListOf<String>() }
    val ocrQuantities = remember { mutableStateMapOf<String, String>() }
    val ocrAmounts = remember { mutableStateMapOf<String, String>() }
    val ocrPrices = remember { mutableStateMapOf<String, String>() }
    var ocrDate by remember { mutableStateOf(LocalDate.now().toString()) }
    var ocrGrandTotal by remember { mutableStateOf("") }
    var editingSale by remember { mutableStateOf<SaleLineEntity?>(null) }
    var editSaleQty by remember { mutableStateOf("") }
    var editSaleAmount by remember { mutableStateOf("") }
    var deleteSale by remember { mutableStateOf<SaleLineEntity?>(null) }
    fun detectOcrSkus(raw: String) {
        ocrCandidates.clear()
        ocrQuantities.clear()
        ocrAmounts.clear()
        ocrPrices.clear()
        Regex("20\\d{2}[-/]\\d{1,2}[-/]\\d{1,2}").find(raw)?.value?.replace("/", "-")?.let { candidate -> runCatching { ocrDate = LocalDate.parse(candidate).toString() } }
        Regex("(?i)grand\\s*total[^0-9]*([0-9,]{4,})").find(raw)?.groupValues?.getOrNull(1)?.let { ocrGrandTotal = it.replace(",", "") }
        val normalized = raw.lowercase().replace(Regex("\\s+"), " ")
        skuList.sortedByDescending { it.name.length }.forEach { product ->
            val key = product.name.lowercase()
            val found = when (key) {
                "pull သေး" -> Regex("pull\\s*1(?!\\s*nb)(?:\\s*(?:s|m|l|xl|3xl))?").containsMatchIn(normalized) || normalized.contains("pull သေး")
                "pull 1 nb" -> normalized.contains("pull 1 nb") || normalized.contains("pull nb")
                "blue 423" -> normalized.contains("blue423") || normalized.contains("blue 423")
                "blue 409" -> normalized.contains("blue409") || normalized.contains("blue 409")
                else -> normalized.contains(key)
            }
            if (found && product.name !in ocrCandidates) {
                ocrCandidates.add(product.name)
                ocrQuantities[product.name] = ""
                ocrAmounts[product.name] = ""
                ocrPrices[product.name] = product.pricePerPack.toString()
            }
        }
    }
    val today = LocalDate.now()
    val todaySales = sales.filter { it.inPeriod(Period.DAILY, today) }
    val weekSales = sales.filter { it.inPeriod(Period.WEEKLY, today) }
    val monthSales = sales.filter { it.inPeriod(Period.MONTHLY, today) }
    val totalToday = todaySales.sumOf { it.amountMmk } + (manualAmounts[today.toString()] ?: 0L)
    val totalMonth = monthSales.sumOf { it.amountMmk } + manualAmounts.filterKeys { runCatching { LocalDate.parse(it).let { d -> d.year == today.year && d.month == today.month } }.getOrDefault(false) }.values.sum()
    val reportRows = sales.filter { it.inPeriod(period, today) }
    val reportManualTotal = manualAmounts.filterKeys { key -> runCatching { val d = LocalDate.parse(key); when (period) { Period.DAILY -> d == today; Period.WEEKLY -> !d.isBefore(today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))) && !d.isAfter(today); Period.MONTHLY -> d.year == today.year && d.month == today.month } }.getOrDefault(false) }.values.sum()
    val reportTotal = reportRows.sumOf { it.amountMmk } + reportManualTotal
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            loading = true
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            val results = arrayOfNulls<String>(uris.size)
            var remaining = uris.size
            uris.forEachIndexed { index, uri ->
                try {
                    recognizer.process(InputImage.fromFilePath(context, uri))
                        .addOnSuccessListener { results[index] = "ပုံ ${index + 1}\n${it.text}" }
                        .addOnFailureListener { results[index] = "ပုံ ${index + 1}: ဖတ်မရပါ" }
                        .addOnCompleteListener {
                            remaining--
                            if (remaining == 0) { ocrText = results.filterNotNull().joinToString("\n\n---\n\n"); detectOcrSkus(ocrText); loading = false; recognizer.close() }
                        }
                } catch (_: Exception) {
                    results[index] = "ပုံ ${index + 1}: ဖွင့်မရပါ"
                    remaining--
                    if (remaining == 0) { ocrText = results.filterNotNull().joinToString("\n"); detectOcrSkus(ocrText); loading = false; recognizer.close() }
                }
            }
        }
    }

    DisposableEffect(mapView) {
        mapView?.onResume()
        onDispose { mapView?.onPause() }
    }
    MaterialTheme(colorScheme = lightColorScheme(primary = Accent, onPrimary = Color.White, primaryContainer = Panel2, onPrimaryContainer = Ink, background = Navy, onBackground = Ink, surface = Panel, onSurface = Ink, secondary = Color(0xFF3D83C6), onSecondary = Color.White, surfaceVariant = Panel2, onSurfaceVariant = Muted, outline = Color(0xFFD4DFEA))) {
        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = {
                ModalDrawerSheet(
                    modifier = Modifier.fillMaxHeight().background(DashboardBlue).border(2.dp, DashboardBlue, RoundedCornerShape(topEnd = 18.dp, bottomEnd = 18.dp)),
                    drawerContainerColor = DashboardBlue, drawerContentColor = Color.White,
                    drawerShape = RoundedCornerShape(topEnd = 18.dp, bottomEnd = 18.dp)
                ) {
                    Column(Modifier.fillMaxWidth().background(Accent).padding(20.dp)) {
                        Text("MO MO", color = Color.White, fontWeight = FontWeight.Black, style = MaterialTheme.typography.headlineMedium)
                        Text("မှော်ဘီ • SALES MANAGEMENT", color = Color.White.copy(alpha = 0.88f), style = MaterialTheme.typography.labelSmall)
                    }
                    HorizontalDivider(color = Color.White.copy(alpha = 0.35f))
                    Page.entries.forEach { p ->
                        NavigationDrawerItem(label = { Text("${p.icon}   ${p.label}") }, selected = page == p,
                            onClick = { navigateTo(p); scope.launch { drawerState.close() } }, modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp),
                            colors = NavigationDrawerItemDefaults.colors(selectedContainerColor = Color.White, selectedTextColor = DashboardBlue, unselectedContainerColor = DashboardBlue, unselectedTextColor = Color.White))
                    }
                }
            }
        ) {
            Scaffold(containerColor = Navy, topBar = {
                TopAppBar(
                    title = { Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        androidx.compose.foundation.Image(painter = painterResource(id = R.mipmap.ic_launcher), contentDescription = "Mo Mo Logo", modifier = Modifier.size(38.dp), contentScale = ContentScale.Fit)
                        Column { Text("MoMo(Hmawbi)", fontWeight = FontWeight.Bold, color = Color.White); Text(page.label, color = Color.White.copy(alpha = 0.88f), style = MaterialTheme.typography.labelSmall) }
                    } },
                    navigationIcon = {
                        // Use the phone's system Back button; keep only the navigation drawer control here.
                        Text("☰", color = Color.White, modifier = Modifier.clickable { scope.launch { drawerState.open() } }.padding(horizontal = 12.dp), style = MaterialTheme.typography.headlineSmall)
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = DashboardBlue, titleContentColor = Color.White, navigationIconContentColor = Color.White, actionIconContentColor = Color.White)
                )
            }) { padding ->
                LazyColumn(Modifier.fillMaxSize().background(if (page == Page.DASHBOARD) Navy else Color(0xFFF1F5FB)).padding(padding).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(bottom = 28.dp)) {
                    when (page) {
                        Page.DASHBOARD -> {
                            item { Column { Text(today.format(DateTimeFormatter.ofPattern("EEEE, dd MMMM yyyy")), color = Color(0xFFB9D8FF)); Text("Business overview", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) } }
                            item {
                                val achievement = totalMonth.toDouble() / MONTHLY_TARGET_MMK.toDouble()
                                val achievementPercent = achievement * 100.0
                                val monthlyReached80 = achievement >= 0.80
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    MetricCard(
                                        "DAILY SALES", totalToday.mmk(), "${todaySales.size} transactions",
                                        Modifier.weight(1f), DailyBright, Color.White
                                    )
                                    MetricCard(
                                        "MONTHLY SALES", totalMonth.mmk(),
                                        "Achievement ${"%.1f".format(java.util.Locale.US, achievementPercent)}%\nTarget ${MONTHLY_TARGET_MMK.mmk()}",
                                        Modifier.weight(1f),
                                        MonthlyBright, Color.White
                                    )
                                }
                            }
                            item {
                                val achievement = (totalMonth.toDouble() / MONTHLY_TARGET_MMK.toDouble()).coerceAtLeast(0.0)
                                val percent = achievement * 100.0
                                val remaining = (MONTHLY_TARGET_MMK - totalMonth).coerceAtLeast(0L)
                                AchievementCard(
                                    actual = totalMonth,
                                    target = MONTHLY_TARGET_MMK,
                                    remaining = remaining,
                                    percent = percent,
                                    progress = achievement.coerceIn(0.0, 1.0).toFloat()
                                )
                            }
                            item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { MetricCard("TOTAL RECORDS", sales.size.toString(), "Saved sales lines", Modifier.weight(1f)); MetricCard("MODE", "OFFLINE", "Local database", Modifier.weight(1f)) } }
                            item { SectionTitle("QUICK ACTIONS") }
                            item { Page.entries.filter { it == Page.ENTRY || it == Page.REPORTS || it == Page.OCR || it == Page.HISTORY }.chunked(2).forEach { row -> Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { row.forEach { p -> ActionCard(p.icon, p.label, Modifier.weight(1f)) { navigateTo(p) } }; if (row.size == 1) Spacer(Modifier.weight(1f)) } ; Spacer(Modifier.height(8.dp)) } }
                            item { SectionTitle("RECENT SALES") }
                            if (sales.isEmpty()) item { InfoCard("အရောင်းမှတ်တမ်း မရှိသေးပါ။ Daily Sales မှ စတင်သွင်းနိုင်ပါတယ်။") }
                            items(sales.take(5)) { SaleCard(it.skuName, "${it.packQuantity} packs", it.amountMmk.mmk(), it.createdAt.asDate().toString()) }
                        }
                        Page.ENTRY -> {
                            item { SectionTitle("DAILY SALES ENTRY") }
                            item { SurfaceCard {
                                Text("MANUAL DAILY AMOUNT", color = Accent, fontWeight = FontWeight.ExtraBold)
                                Text("SKU စာရင်းမရွေးဘဲ နေ့စွဲအလိုက် ရောင်းရငွေစုစုပေါင်း ထည့်ရန်", color = Muted, style = MaterialTheme.typography.bodySmall)
                                OutlinedButton(onClick = { showAmountDatePicker = true }, modifier = Modifier.fillMaxWidth()) { Text("ရောင်းသည့်နေ့: ${amountDate.format(DateTimeFormatter.ofPattern("dd MMM yyyy"))}  •  ရက်ရွေးရန်") }
                                Text("ဒီနေ့ရွေးထားသောရက်၏ လက်ရှိ Amount: ${(manualAmounts[amountDate.toString()] ?: 0L).mmk()}", color = Ink, fontWeight = FontWeight.SemiBold)
                                if (amountUnlocked) {
                                    OutlinedTextField(value = amountText, onValueChange = { amountText = it.filter(Char::isDigit).take(14) }, label = { Text("ရောင်းရငွေ စုစုပေါင်း (ကျပ်)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                    Button(onClick = { val amount = amountText.toLongOrNull(); if (amount == null || amount < 0L) notice = "Amount မှန်ကန်စွာ ဖြည့်ပါ" else { saveManualAmount(amountDate, amount); notice = "${amountDate} အတွက် Amount သိမ်းပြီးပါပြီ"; amountUnlocked = false; amountText = "" } }, modifier = Modifier.fillMaxWidth()) { Text("Amount သိမ်းမယ်") }
                                    TextButton(onClick = { amountUnlocked = false; amountText = "" }) { Text("Lock ပြန်လုပ်မယ်") }
                                } else {
                                    Button(onClick = { amountPinEntry = ""; showAmountPinDialog = true }, modifier = Modifier.fillMaxWidth()) { Text("Owner PIN ဖြင့် Amount ထည့်ရန်") }
                                }
                            } }
                            item { SurfaceCard {
                                ExposedDropdownMenuBox(expanded = skuMenu, onExpandedChange = { skuMenu = !skuMenu }) {
                                    OutlinedTextField(value = sku.name, onValueChange = {}, readOnly = true, label = { Text("SKU ရွေးရန်") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(skuMenu) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                                    ExposedDropdownMenu(expanded = skuMenu, onDismissRequest = { skuMenu = false }) { skuList.forEach { item -> DropdownMenuItem(text = { Text("${item.name} • ${item.category.label}") }, onClick = { sku = item; unit = ReceiptUnit.PACK; skuMenu = false }) } }
                                }
                                OutlinedTextField(value = qtyText, onValueChange = { qtyText = it.filter(Char::isDigit).take(7) }, label = { Text("ဘောင်ချာ Qty") }, modifier = Modifier.fillMaxWidth())
                                ExposedDropdownMenuBox(expanded = unitMenu, onExpandedChange = { unitMenu = !unitMenu }) {
                                    OutlinedTextField(value = unit.name, onValueChange = {}, readOnly = true, label = { Text("Qty ယူနစ်") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(unitMenu) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                                    ExposedDropdownMenu(expanded = unitMenu, onDismissRequest = { unitMenu = false }) { ReceiptUnit.entries.forEach { u -> DropdownMenuItem(text = { Text(u.name) }, onClick = { unit = u; unitMenu = false }) } }
                                }
                                val q = qtyText.toIntOrNull() ?: 0
                                val packs = sku.toPacks(q, unit)
                                Text("Pack Qty: $packs", color = Muted)
                                Text("Amount: ${(packs.toLong() * currentPrice(sku)).mmk()}", color = Accent, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                Button(onClick = {
                                    val valid = q > 0 && when (unit) { ReceiptUnit.PACK -> true; ReceiptUnit.BAG -> sku.packsPerBag > 1; ReceiptUnit.CARTON -> sku.packsPerCarton > 1 }
                                    if (valid) scope.launch { dao.insert(SaleLineEntity(skuName = sku.name, category = sku.category.name, receiptQuantity = q, receiptUnit = unit.name, packQuantity = packs, unitPriceMmk = currentPrice(sku), amountMmk = packs.toLong() * currentPrice(sku))); notice = "အရောင်းစာရင်း သိမ်းပြီးပါပြီ"; qtyText = "1" } else notice = "Qty / Unit ကို ပြန်စစ်ပါ"
                                }, modifier = Modifier.fillMaxWidth()) { Text("အရောင်းစာရင်း သိမ်းမယ်") }
                                if (notice.isNotBlank()) Text(notice, color = Accent)
                            } }
                        }
                        Page.REPORTS -> {
                            item { SectionTitle("SALES ANALYTICS") }
                            item { SurfaceCard {
                                SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) { Period.entries.forEachIndexed { i, p -> SegmentedButton(selected = period == p, onClick = { period = p }, shape = SegmentedButtonDefaults.itemShape(i, Period.entries.size)) { Text(p.label) } } }
                                Text("${period.label} total", color = Muted)
                                Text(reportTotal.mmk(), color = Accent, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                                Text("${reportRows.size} sales lines", color = Muted)
                                HorizontalDivider(color = Panel2)
                                Text("CATEGORY PERFORMANCE • ${period.label.uppercase()}", color = Accent, fontWeight = FontWeight.Bold)
                                Category.entries.forEach { c ->
                                    val actual = reportRows.filter { it.category == c.name }.sumOf { it.amountMmk }
                                    val target = c.targetFor(period)
                                    val achievement = if (target > 0) actual.toDouble() * 100.0 / target else 0.0
                                    Column(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                            Text(c.label, fontWeight = FontWeight.SemiBold, color = Ink)
                                            Text("${"%.0f".format(java.util.Locale.US, achievement)}%", color = if (achievement >= 100) LightGreenInk else Accent, fontWeight = FontWeight.Bold)
                                        }
                                        Text("Target: ${target.mmk()}", color = Muted, style = MaterialTheme.typography.bodySmall)
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("Actual: ${actual.mmk()}", color = Ink, style = MaterialTheme.typography.bodyMedium)
                                            Text("${if (actual >= target) "Over" else "Left"}: ${kotlin.math.abs(target - actual).mmk()}", color = Muted, style = MaterialTheme.typography.bodySmall)
                                        }
                                        LinearProgressIndicator(progress = { (achievement / 100.0).coerceIn(0.0, 1.0).toFloat() }, modifier = Modifier.fillMaxWidth(), color = Accent, trackColor = Panel2)
                                    }
                                    HorizontalDivider(color = Panel2)
                                }
                                Button(onClick = {
                                    val content = Category.entries.joinToString("\n") { c ->
                                        val actual = reportRows.filter { it.category == c.name }.sumOf { it.amountMmk }
                                        "${c.label}\t${c.targetFor(period)}\t$actual\t${if (c.targetFor(period) > 0) actual * 100 / c.targetFor(period) else 0}%"
                                    }
                                    clipboard.setText(AnnotatedString(content)); notice = "Category Performance ကို Copy ကူးပြီးပါပြီ"
                                }, modifier = Modifier.fillMaxWidth()) { Text("Category Performance Copy") }
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(onClick = {
                                        val content = sheetsActualCopyText(monthSales)
                                        clipboard.setText(AnnotatedString(content))
                                        notice = "Monthly Actual ငါးကြောင်းကို Sheets အတွက် Copy ကူးပြီးပါပြီ"
                                    }, modifier = Modifier.weight(1f)) { Text("Monthly Actual Copy") }
                                    OutlinedButton(onClick = {
                                        val content = sheetsActualCopyText(weekSales)
                                        clipboard.setText(AnnotatedString(content))
                                        notice = "Weekly Actual ငါးကြောင်းကို Sheets အတွက် Copy ကူးပြီးပါပြီ"
                                    }, modifier = Modifier.weight(1f)) { Text("Weekly Actual Copy") }
                                }
                                OutlinedButton(onClick = {
                                    val content = sheetsActualCopyText(todaySales)
                                    clipboard.setText(AnnotatedString(content))
                                    notice = "Daily Actual ငါးကြောင်းကို Sheets အတွက် Copy ကူးပြီးပါပြီ"
                                }, modifier = Modifier.fillMaxWidth()) { Text("Daily Actual Copy") }
                                Text("Copy လုပ်ထားတဲ့ ငါးကြောင်းကို Google Sheets ရဲ့ သက်ဆိုင်ရာ Actual ကော်လံ ပထမ Category အကွက်မှာ Paste လုပ်ပါ။ အစဉ်လိုက် - Sanitary, Baby Diaper, Adult, Wet Tissue, Dry Tissue။", color = Muted, style = MaterialTheme.typography.bodySmall)
                                HorizontalDivider(color = Panel2)
                                Text("SKU SUMMARY", color = Accent, fontWeight = FontWeight.Bold)
                                val skuGroups = reportRows.groupBy { SalesCalculator.canonicalSkuName(it.skuName) }.toSortedMap()
                                skuGroups.forEach { (name, rows) -> Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween) { Column(Modifier.weight(1f)) { Text(name); Text("Qty: ${rows.sumOf { it.packQuantity }} packs", color = Muted, style = MaterialTheme.typography.bodySmall) }; Text(rows.sumOf { it.amountMmk }.mmk()) } }
                                Button(onClick = {
                                    val content = skuGroups.entries.joinToString("\n") { (name, rows) -> "$name\t${rows.sumOf { it.packQuantity }}\t${rows.sumOf { it.amountMmk }}" }
                                    clipboard.setText(AnnotatedString(content)); notice = "SKU Summary ကို Copy ကူးပြီးပါပြီ"
                                }, modifier = Modifier.fillMaxWidth()) { Text("SKU Summary Copy") }
                                if (notice.isNotBlank()) Text(notice, color = Accent)
                            } }
                        }
                        Page.PRODUCTS -> {
                            item { SectionTitle("PRODUCT & PRICE MASTER") }
                            item { Button(onClick = { showAddSkuDialog = true }, modifier = Modifier.fillMaxWidth()) { Text("＋ SKU အသစ်ထည့်ရန်") } }
                            item { InfoCard("SKU တစ်ခုချင်းစီ၏ တစ်ထုပ်ဈေးနှုန်းကို Owner PIN ဖြင့် ပြင်နိုင်ပါတယ်။ Pull 1 NB ကို သီးခြား SKU အဖြစ်ထားပြီး Pull 1 size များကို Pull သေး အဖြစ်ပေါင်းပြထားပါတယ်။ ပြင်ထားသောဈေးနှုန်းကို ဒီဖုန်းထဲမှာ သိမ်းထားပြီး နောက်ထပ်အရောင်းအသစ်များတွင် အသုံးပြုပါမယ်။ ယခင်အရောင်းမှတ်တမ်းများ၏ ဈေးနှုန်းကို မပြောင်းပါ။") }
                            items(skuList.toList()) { product ->
                                SurfaceCard {
                                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                        val photoUri = productPhotos[product.name]
                                        val bundledRes = bundledPhoto(product)
                                        if (photoUri != null || bundledRes != 0) {
                                            AndroidView(
                                                factory = { ctx -> ImageView(ctx).apply { scaleType = ImageView.ScaleType.CENTER_CROP } },
                                                update = { view ->
                                                    runCatching {
                                                        if (photoUri != null) view.setImageURI(Uri.parse(photoUri))
                                                        else view.setImageResource(bundledRes)
                                                    }
                                                },
                                                modifier = Modifier.size(76.dp)
                                            )
                                        } else {
                                            Surface(Modifier.size(76.dp), color = Panel2, shape = RoundedCornerShape(12.dp)) {
                                                Box(contentAlignment = Alignment.Center) { Text("📦", style = MaterialTheme.typography.headlineMedium) }
                                            }
                                        }
                                        Column(Modifier.weight(1f)) {
                                            Text(product.name, fontWeight = FontWeight.SemiBold)
                                            Text(product.category.label, color = Muted, style = MaterialTheme.typography.bodySmall)
                                            Text(currentPrice(product).mmk(), color = Accent, fontWeight = FontWeight.Bold)
                                            Row {
                                                TextButton(onClick = {
                                                    if (!ownerPriceUnlocked) { editingSku = product; editedPriceText = currentPrice(product).toString(); showOwnerPinDialog = true }
                                                    else { editingSku = product; editedPriceText = currentPrice(product).toString() }
                                                }) { Text("ဈေးပြင်") }
                                                if (SkuMaster.findByName(product.name) == null) {
                                                    TextButton(onClick = {
                                                        if (!ownerPriceUnlocked) { editingSku = product; showOwnerPinDialog = true }
                                                        else {
                                                            skuList.remove(product)
                                                            saveCustomSkus()
                                                            notice = "SKU ကို စာရင်းမှ ဖယ်ရှားပြီးပါပြီ"
                                                        }
                                                    }) { Text("ဖျက်") }
                                                }
                                            }
                                            Row {
                                                TextButton(onClick = {
                                                    photoTargetSku = product.name
                                                    productPhotoPicker.launch(arrayOf("image/*"))
                                                }) { Text(if (photoUri == null) "ပုံထည့်ရန်" else "ပုံပြောင်းရန်") }
                                                if (photoUri != null) {
                                                    TextButton(onClick = {
                                                        productPhotos.remove(product.name)
                                                        productPhotoPrefs.edit().remove(product.name).apply()
                                                        notice = "${product.name} ပုံဖျက်ပြီးပါပြီ"
                                                    }) { Text("ပုံဖျက်") }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        Page.MAP -> {
                            item { SectionTitle("CUSTOMER MAP • HMAWBI 50 KM") }
                            item {
                                SurfaceCard {
                                    Text("OpenStreetMap • မှော်ဘီဗဟို", color = Accent, fontWeight = FontWeight.Bold)
                                    AndroidView(factory = { ctx ->
                                        Configuration.getInstance().userAgentValue = ctx.packageName
                                        MapView(ctx).apply {
                                            setTileSource(TileSourceFactory.MAPNIK)
                                            setMultiTouchControls(true)
                                            controller.setZoom(11.0)
                                            controller.setCenter(GeoPoint(17.072, 96.067))
                                            val radiusCircle = Polygon().apply {
                                                points = (0..72).map { i ->
                                                    val angle = Math.toRadians(i * 5.0)
                                                    val lat = 17.072 + (50_000.0 / 111_320.0) * cos(angle)
                                                    val lon = 96.067 + (50_000.0 / (111_320.0 * cos(Math.toRadians(17.072)))) * sin(angle)
                                                    GeoPoint(lat, lon)
                                                }
                                                fillPaint.color = android.graphics.Color.argb(24, 23, 105, 170)
                                                outlinePaint.color = android.graphics.Color.rgb(23, 105, 170)
                                                outlinePaint.strokeWidth = 3f
                                            }
                                            overlays.add(radiusCircle)
                                            mapView = this
                                        }
                                    }, update = { mv ->
                                        mv.overlays.removeAll { it is Marker }
                                        customerPins.forEach { pin ->
                                            Marker(mv).apply { position = GeoPoint(pin.second, pin.third); title = pin.first; setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM); mv.overlays.add(this) }
                                        }
                                        mv.invalidate()
                                    }, modifier = Modifier.fillMaxWidth().height(360.dp))
                                    Text("မြေပုံကို Zoom ဆွဲပြီး ဆိုင်တည်နေရာတွေ ကြည့်နိုင်ပါတယ်။ အင်တာနက်ရှိချိန်မှာ မြေပုံ Tile တွေကို အလိုအလျောက် cache လုပ်ထားနိုင်ပေမယ့် 50 km တစ်ခုလုံးကို Offline Download လုပ်ခြင်း မပါသေးပါ။", color = Muted, style = MaterialTheme.typography.bodySmall)
                                    Button(onClick = {
                                        val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                                        val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                                        if (fine || coarse) {
                                            val lm = context.getSystemService(android.content.Context.LOCATION_SERVICE) as LocationManager
                                            val loc = runCatching { lm.getLastKnownLocation(if (fine) LocationManager.GPS_PROVIDER else LocationManager.NETWORK_PROVIDER) }.getOrNull()
                                            if (loc != null) mapView?.controller?.animateTo(GeoPoint(loc.latitude, loc.longitude)) else notice = "GPS တည်နေရာ မရသေးပါ။ Location ဖွင့်ပြီး ထပ်နှိပ်ပါ။"
                                        } else locationPermission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                                    }, modifier = Modifier.fillMaxWidth()) { Text("◎ လက်ရှိ GPS တည်နေရာ") }
                                }
                            }
                            item {
                                SurfaceCard {
                                    Text("CUSTOMER ဆိုင် Pin အသစ်ထည့်ရန်", color = Accent, fontWeight = FontWeight.Bold)
                                    OutlinedTextField(customerName, { customerName = it }, label = { Text("ဆိုင်အမည်") }, modifier = Modifier.fillMaxWidth())
                                    OutlinedTextField(customerLat, { customerLat = it }, label = { Text("Latitude") }, modifier = Modifier.fillMaxWidth())
                                    OutlinedTextField(customerLon, { customerLon = it }, label = { Text("Longitude") }, modifier = Modifier.fillMaxWidth())
                                    Button(onClick = {
                                        val la = customerLat.toDoubleOrNull(); val lo = customerLon.toDoubleOrNull()
                                        if (customerName.isNotBlank() && la != null && lo != null && la in -90.0..90.0 && lo in -180.0..180.0) {
                                            customerPins.add(Triple(customerName.trim(), la, lo)); persistCustomerPins(); customerName = ""; customerLat = ""; customerLon = ""; mapView?.invalidate(); notice = "ဆိုင် Pin သိမ်းပြီးပါပြီ"
                                        } else notice = "ဆိုင်အမည်နဲ့ Latitude / Longitude မှန်ကန်စွာ ဖြည့်ပါ။"
                                    }, modifier = Modifier.fillMaxWidth()) { Text("ဆိုင် Pin သိမ်းမယ်") }
                                }
                            }
                            items(customerPins.toList()) { pin ->
                                SurfaceCard {
                                    Text(pin.first, color = Accent, fontWeight = FontWeight.Bold)
                                    Text("${pin.second}, ${pin.third}", color = Muted)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedButton(onClick = { mapView?.controller?.animateTo(GeoPoint(pin.second, pin.third)); mapView?.controller?.setZoom(16.0) }, modifier = Modifier.weight(1f)) { Text("Map ပေါ်ကြည့်") }
                                        OutlinedButton(onClick = { runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=${pin.second},${pin.third}"))) }.onFailure { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:${pin.second},${pin.third}?q=${pin.second},${pin.third}(${Uri.encode(pin.first)})"))) } }, modifier = Modifier.weight(1f)) { Text("လမ်းကြောင်း") }
                                        TextButton(onClick = { customerPins.remove(pin); persistCustomerPins() }) { Text("ဖျက်") }
                                    }
                                }
                            }
                        }
                        Page.OCR -> {
                            item { SectionTitle("RECEIPT OCR SCANNER") }
                            item { SurfaceCard {
                                Button(onClick = { picker.launch("image/*") }, enabled = !loading, modifier = Modifier.fillMaxWidth()) { Text("Gallery မှ Screenshot ရွေးရန်") }
                                if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Text("OCR ဖတ်ထားသော စာသား", color = Accent, fontWeight = FontWeight.Bold)
                                    TextButton(onClick = { clipboard.setText(AnnotatedString(ocrText)); notice = "OCR စာသား Copy ကူးပြီးပါပြီ" }) { Text("စာသား Copy") }
                                }
                                Text(ocrText, color = Ink)
                                OutlinedTextField(value = ocrDate, onValueChange = { ocrDate = it }, label = { Text("Date (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth())
                                OutlinedTextField(value = ocrGrandTotal, onValueChange = { ocrGrandTotal = it.filter(Char::isDigit).take(12) }, label = { Text("Grand Total (ကျပ်)") }, modifier = Modifier.fillMaxWidth())
                                Text("SKU / Qty / Price / Amount ကို ဘောင်ချာနဲ့တိုက်စစ်ပြီးမှ သိမ်းပါ။ Outlet / Staff မသိမ်းပါ။", color = Muted, style = MaterialTheme.typography.bodySmall)
                                val enteredAmountTotal = ocrCandidates.sumOf { ocrAmounts[it]?.toLongOrNull() ?: 0L }
                                val receiptTotal = ocrGrandTotal.toLongOrNull()
                                if (receiptTotal != null && enteredAmountTotal > 0L) {
                                    Text(if (enteredAmountTotal == receiptTotal) "✓ Line Amount စုစုပေါင်း = Grand Total" else "⚠ Line Amount စုစုပေါင်း ${enteredAmountTotal.mmk()} • Grand Total ${receiptTotal.mmk()} — မကိုက်ညီသေးပါ", color = if (enteredAmountTotal == receiptTotal) LightGreenInk else LightRedInk, fontWeight = FontWeight.Bold)
                                }
                            } }
                            if (ocrCandidates.isNotEmpty()) {
                                item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    SectionTitle("SKU / Qty / Amount • တိုက်စစ်ရန်")
                                    TextButton(onClick = {
                                        val txt = buildString {
                                            append("Date\tSKU\tQty\tPrice\tAmount\n")
                                            ocrCandidates.forEach { n -> append(ocrDate).append("\t").append(n).append("\t").append(ocrQuantities[n].orEmpty()).append("\t").append(ocrPrices[n].orEmpty()).append("\t").append(ocrAmounts[n].orEmpty()).append("\n") }
                                        }
                                        clipboard.setText(AnnotatedString(txt)); notice = "SKU / Qty / Amount Copy ကူးပြီးပါပြီ"
                                    }) { Text("စာရင်း Copy") }
                                } }
                                item { Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("SKU / Qty / Price / Amount ကို အောက်မှာ သီးခြားစစ်ပါ", color = Muted, fontWeight = FontWeight.Bold)
                                } }
                                items(ocrCandidates.toList()) { name ->
                                    val product = skuList.firstOrNull { it.name == name }
                                    if (product != null) SurfaceCard {
                                        Text(product.name, color = Accent, fontWeight = FontWeight.Bold)
                                        Text(product.category.label, color = Muted, style = MaterialTheme.typography.bodySmall)
                                        OutlinedTextField(
                                            value = ocrQuantities[name] ?: "",
                                            onValueChange = { value ->
                                                val digits = value.filter(Char::isDigit).take(7)
                                                ocrQuantities[name] = digits
                                                val q = digits.toLongOrNull() ?: 0L
                                                val p = ocrPrices[name]?.toLongOrNull() ?: 0L
                                                ocrAmounts[name] = if (q > 0L && p > 0L) runCatching { Math.multiplyExact(q, p) }.getOrNull()?.toString().orEmpty() else ""
                                            },
                                            label = { Text("Qty (ဘောင်ချာအတိုင်း)") },
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                        OutlinedTextField(
                                            value = ocrPrices[name] ?: "",
                                            onValueChange = { value ->
                                                val digits = value.filter(Char::isDigit).take(12)
                                                ocrPrices[name] = digits
                                                val q = ocrQuantities[name]?.toLongOrNull() ?: 0L
                                                val p = digits.toLongOrNull() ?: 0L
                                                ocrAmounts[name] = if (q > 0L && p > 0L) runCatching { Math.multiplyExact(q, p) }.getOrNull()?.toString().orEmpty() else ""
                                            },
                                            label = { Text("Price (တစ်ခု/တစ်ထုပ် ကျပ်)") },
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                        OutlinedTextField(
                                            value = ocrAmounts[name] ?: "",
                                            onValueChange = { ocrAmounts[name] = it.filter(Char::isDigit).take(12) },
                                            label = { Text("Amount (အလိုအလျောက်တွက်ပြီး ပြင်နိုင်သည်)") },
                                            supportingText = { Text("Qty × Price ဖြင့် အလိုအလျောက်တွက်ပေးမယ်။ ဘောင်ချာနဲ့ မတူရင် ဒီနေရာမှာ ကိုယ်တိုင်ပြင်နိုင်ပါတယ်။") },
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                        Button(onClick = {
                                            val qty = ocrQuantities[name]?.toIntOrNull() ?: 0
                                            val amount = ocrAmounts[name]?.toLongOrNull() ?: 0L
                                            val price = ocrPrices[name]?.toLongOrNull() ?: 0L
                                            val recordDate = runCatching { LocalDate.parse(ocrDate) }.getOrNull()
                                            if (qty > 0 && amount > 0L && price > 0L && recordDate != null) scope.launch {
                                                val created = recordDate.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
                                                dao.insert(SaleLineEntity(skuName = name, category = product.category.name, receiptQuantity = qty, receiptUnit = "RECEIPT", packQuantity = qty, unitPriceMmk = price, amountMmk = amount, createdAt = created))
                                                ocrCandidates.remove(name); ocrQuantities.remove(name); ocrAmounts.remove(name); ocrPrices.remove(name)
                                                notice = "$name အရောင်းစာရင်း သိမ်းပြီးပါပြီ"
                                            } else notice = "Date / Qty / Price / Amount ကို ပြန်စစ်ပါ"
                                        }, modifier = Modifier.fillMaxWidth()) { Text("စစ်ပြီး သိမ်းမယ်") }
                                    }
                                }
                            } else if (ocrText.isNotBlank() && !loading) {
                                item { InfoCard("Master SKU အမည်ကို OCR စာသားထဲတွင် မတွေ့ပါ။ မသေချာသော SKU ကို အလိုအလျောက်မသိမ်းပါ။ Daily Sales မှ ကိုယ်တိုင်ထည့်နိုင်ပါတယ်။") }
                            }
                            if (notice.isNotBlank()) item { Text(notice, color = Accent) }
                        }
                        Page.HISTORY -> {
                            item { SectionTitle("SALES HISTORY • ${sales.size} RECORDS") }
                            if (sales.isEmpty()) item { InfoCard("သိမ်းထားသော အရောင်းစာရင်း မရှိသေးပါ။") }
                            items(sales, key = { it.id }) { line ->
                                SurfaceCard {
                                    Text(line.skuName, color = Accent, fontWeight = FontWeight.Bold)
                                    Text("${line.category} • Qty ${line.receiptQuantity} • ${line.amountMmk.mmk()}", color = Ink)
                                    Text(Instant.ofEpochMilli(line.createdAt).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm")), color = Muted, style = MaterialTheme.typography.labelSmall)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedButton(onClick = { editingSale = line; editSaleQty = line.receiptQuantity.toString(); editSaleAmount = line.amountMmk.toString() }, modifier = Modifier.weight(1f)) { Text("ပြင်မယ်") }
                                        OutlinedButton(onClick = { deleteSale = line }, modifier = Modifier.weight(1f), colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFB3261E))) { Text("ဖျက်မယ်") }
                                    }
                                }
                            }
                        }
                        Page.SETTINGS -> {
                            item { SectionTitle("APP INFORMATION") }
                            item {
                                SurfaceCard {
                                    Text("MoMo (Hmawbi)", color = Accent, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                    Text("App Version  •  V1.2.0", color = Accent, fontWeight = FontWeight.Bold)
                                    HorizontalDivider(color = Panel2)
                                    Text("Developed by Phyo Thet Htun 🇲🇲", color = Ink, fontWeight = FontWeight.SemiBold, modifier = Modifier.clickable { showDeveloperPopup = true })
                                }
                            }
                            item { SectionTitle("BACKUP / RESTORE") }
                            item {
                                SurfaceCard {
                                    Text("ဒေတာအရန်သိမ်းဆည်းခြင်း", color = Ink, fontWeight = FontWeight.Bold)
                                    Text("အရောင်းစာရင်း၊ SKU၊ ဈေးနှုန်း၊ Customer Map နှင့် ထုတ်ကုန်ဓာတ်ပုံဖိုင်များကို ZIP ဖိုင်တစ်ခုအဖြစ် သိမ်းနိုင်ပါတယ်။ Restore မလုပ်မီ Backup အချက်အလက်များကို စစ်ဆေးပြီး လက်ရှိဒေတာကို အရန်ထားပါမယ်။", color = Muted, style = MaterialTheme.typography.bodySmall)
                                    Button(onClick = { backupExporter.launch("MoMo_Hmawbi_Backup.zip") }, modifier = Modifier.fillMaxWidth()) { Text("Backup သိမ်းမယ်") }
                                    OutlinedButton(onClick = { backupImporter.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) }, modifier = Modifier.fillMaxWidth()) { Text("Backup Restore လုပ်မယ်") }
                                    Text("သတိ: Restore သည် Backup ထဲရှိ အချက်အလက်များဖြင့် လက်ရှိစာရင်းကို အစားထိုးပါမယ်။ Backup ZIP ကို ပုံမှန်သိမ်းထားပါ။", color = Color(0xFF9A5B00), style = MaterialTheme.typography.bodySmall)
                                }
                            }
                            item { SectionTitle("OWNER SETTINGS") }
                            item {
                                SurfaceCard {
                                    Text("ဈေးနှုန်း စီမံခန့်ခွဲမှု", color = Ink, fontWeight = FontWeight.Bold)
                                    Text("Owner PIN ဖြင့် ဖွင့်ပြီး SKU ဈေးနှုန်းများကို ပြင်ဆင်နိုင်ပါတယ်။", color = Muted, style = MaterialTheme.typography.bodySmall)
                                    Button(onClick = {
                                        if (ownerPriceUnlocked) ownerPriceUnlocked = false
                                        else { ownerPinEntry = ""; showOwnerPinDialog = true }
                                    }, modifier = Modifier.fillMaxWidth()) { Text(if (ownerPriceUnlocked) "LOCK PRICE SETTINGS" else "OWNER PIN ဖြင့် ဖွင့်ရန်") }
                                }
                            }
                            if (ownerPriceUnlocked) {
                                item { SectionTitle("SKU & PRICE MASTER") }
                                item {
                                    SurfaceCard {
                                        Text("SKU နှင့် ဈေးနှုန်း Master စီမံခန့်ခွဲမှု", color = Ink, fontWeight = FontWeight.Bold)
                                        Text("ဒီနေရာမှာ SKU Master ကိုကြည့်ရှုနိုင်ပြီး SKU အသစ်ထည့်ခြင်းနှင့် SKU တစ်ခုချင်းစီ၏ ဈေးနှုန်းပြင်ဆင်ခြင်းကို လုပ်နိုင်ပါတယ်။ SKU အမည်၊ Category၊ တစ်ထုပ်ဈေးနှုန်း၊ တစ်အိတ်နှင့် တစ် Carton အတွင်း Pack အရေအတွက်များကို သတ်မှတ်ပါ။", color = Muted, style = MaterialTheme.typography.bodySmall)
                                        Button(onClick = {
                                            newSkuName = ""; newSkuPrice = ""; newSkuBag = "1"; newSkuCarton = "1"
                                            newSkuCategory = Category.BABY_DIAPER
                                            showAddSkuDialog = true
                                        }, modifier = Modifier.fillMaxWidth()) { Text("＋ SKU အသစ်ထည့်ရန်") }
                                    }
                                }
                                items(skuList.toList()) { product ->
                                    SurfaceCard {
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                Text(product.name, fontWeight = FontWeight.SemiBold, color = Ink)
                                                Text(product.category.label, color = Muted, style = MaterialTheme.typography.bodySmall)
                                            }
                                            Column(horizontalAlignment = Alignment.End) {
                                                Text(currentPrice(product).mmk(), color = Accent, fontWeight = FontWeight.Bold)
                                                TextButton(onClick = { editingSku = product; editedPriceText = currentPrice(product).toString() }) { Text("ဈေးပြင်ရန်") }
                                            }
                                        }
                                    }
                                }
                            }
                            item { SectionTitle("ABOUT APP") }
                            item {
                                SurfaceCard {
                                    Text("အသုံးပြုရန် အကြံပြုချက်များ", color = Accent, fontWeight = FontWeight.Bold)
                                    Text("၁။ နေ့စဉ်အရောင်းစာရင်းသိမ်းပြီးနောက် Sales History ထဲမှာ ပြန်စစ်ပါ။", color = Ink)
                                    Text("၂။ ဘောင်ချာဓာတ်ပုံမှ OCR ဖတ်ထားသော SKU၊ Qty နဲ့ Amount ကို မသိမ်းခင် မူရင်းဘောင်ချာနဲ့ တိုက်စစ်ပါ။", color = Ink)
                                    Text("၃။ SKU အသစ်ထည့်ရာမှာ Category၊ တစ်ထုပ်ဈေးနှုန်းနဲ့ Bag / Carton Pack အရေအတွက်ကို မှန်ကန်စွာ သတ်မှတ်ပါ။", color = Ink)
                                    Text("၄။ ဈေးနှုန်းပြင်ဆင်မှုသည် နောက်ထပ်အရောင်းအသစ်များအတွက်သာ သက်ရောက်ပြီး ယခင်မှတ်တမ်းများကို မပြောင်းလဲပါ။", color = Ink)
                                    Text("၅။ လက်ရှိ Version သည် Offline အဖြစ် ဖုန်းထဲတွင်သာ သိမ်းဆည်းထားပါသည်။ ဖုန်းပျောက်ခြင်း သို့မဟုတ် App Data ဖျက်မိခြင်းမှ ကာကွယ်ရန် အရေးကြီးစာရင်းများကို သီးခြားမှတ်တမ်းထားပါ။ Cloud Backup မချိတ်ဆက်ရသေးပါ။", color = Muted, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    LaunchedEffect(showAmountDatePicker) {
        if (showAmountDatePicker) {
            val initial = Calendar.getInstance().apply { set(amountDate.year, amountDate.monthValue - 1, amountDate.dayOfMonth) }
            android.app.DatePickerDialog(context, { _, year, month, day ->
                amountDate = LocalDate.of(year, month + 1, day)
                amountText = (manualAmounts[amountDate.toString()] ?: 0L).takeIf { it > 0L }?.toString() ?: ""
                showAmountDatePicker = false
            }, initial.get(Calendar.YEAR), initial.get(Calendar.MONTH), initial.get(Calendar.DAY_OF_MONTH)).apply {
                setOnCancelListener { showAmountDatePicker = false }
            }.show()
        }
    }
    if (showDeveloperPopup) {
        AlertDialog(
            onDismissRequest = { showDeveloperPopup = false },
            title = { Text("Hello from MoMo! ❤️", color = Accent, fontWeight = FontWeight.Bold) },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Image(
                        painter = painterResource(id = R.drawable.developer_puppy),
                        contentDescription = "Developer photo",
                        modifier = Modifier.fillMaxWidth().height(250.dp),
                        contentScale = ContentScale.Crop
                    )
                    Text("Developed by Phyo Thet Htun 🇲🇲", color = Ink, fontWeight = FontWeight.SemiBold)
                    Text("ဒီပုံလေးလိုပဲ နေ့တိုင်း ပျော်ရွှင်ပါစေ ❤️", color = Muted)
                }
            },
            confirmButton = { TextButton(onClick = { showDeveloperPopup = false }) { Text("ပိတ်မယ်") } }
        )
    }
    if (showAmountPinDialog) {
        AlertDialog(onDismissRequest = { showAmountPinDialog = false; amountPinEntry = "" },
            title = { Text("Owner PIN ထည့်ပါ") },
            text = { OutlinedTextField(value = amountPinEntry, onValueChange = { amountPinEntry = it.filter(Char::isDigit).take(6) }, label = { Text("၆ လုံး PIN") }, singleLine = true) },
            confirmButton = { TextButton(onClick = { if (amountPinEntry == "148352") { amountUnlocked = true; amountText = (manualAmounts[amountDate.toString()] ?: 0L).takeIf { it > 0L }?.toString() ?: ""; notice = "Manual Amount ဖွင့်ပြီးပါပြီ" } else notice = "Owner PIN မမှန်ပါ"; showAmountPinDialog = false; amountPinEntry = "" }) { Text("ဖွင့်မယ်") } },
            dismissButton = { TextButton(onClick = { showAmountPinDialog = false; amountPinEntry = "" }) { Text("မလုပ်တော့ပါ") } })
    }
    if (showAddSkuDialog) {
        AlertDialog(
            onDismissRequest = { showAddSkuDialog = false },
            title = { Text("SKU အသစ်ထည့်ရန်") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = newSkuName, onValueChange = { newSkuName = it.take(60) },
                        label = { Text("SKU အမည်") }, singleLine = true)
                    ExposedDropdownMenuBox(expanded = categoryMenu, onExpandedChange = { categoryMenu = !categoryMenu }) {
                        OutlinedTextField(value = newSkuCategory.label, onValueChange = {}, readOnly = true,
                            label = { Text("Category") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(categoryMenu) },
                            modifier = Modifier.menuAnchor().fillMaxWidth())
                        ExposedDropdownMenu(expanded = categoryMenu, onDismissRequest = { categoryMenu = false }) {
                            Category.entries.forEach { c ->
                                DropdownMenuItem(text = { Text(c.label) }, onClick = { newSkuCategory = c; categoryMenu = false })
                            }
                        }
                    }
                    OutlinedTextField(value = newSkuPrice, onValueChange = { newSkuPrice = it.filter(Char::isDigit).take(12) },
                        label = { Text("တစ်ထုပ်ဈေးနှုန်း (ကျပ်)") }, singleLine = true)
                    OutlinedTextField(value = newSkuBag, onValueChange = { newSkuBag = it.filter(Char::isDigit).take(5) },
                        label = { Text("တစ်အိတ်တွင် Pack ဘယ်နှထုပ်") }, singleLine = true)
                    OutlinedTextField(value = newSkuCarton, onValueChange = { newSkuCarton = it.filter(Char::isDigit).take(5) },
                        label = { Text("တစ် Carton တွင် Pack ဘယ်နှထုပ်") }, singleLine = true)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val name = newSkuName.trim()
                    val price = newSkuPrice.toLongOrNull()
                    val bag = newSkuBag.toIntOrNull()
                    val carton = newSkuCarton.toIntOrNull()
                    when {
                        name.isBlank() -> notice = "SKU အမည် ဖြည့်ပါ"
                        skuList.any { it.name.equals(name, true) } -> notice = "ဒီ SKU အမည် ရှိပြီးသားပါ"
                        price == null || price <= 0L -> notice = "ဈေးနှုန်း မှန်ကန်စွာ ဖြည့်ပါ"
                        bag == null || bag < 1 || carton == null || carton < 1 -> notice = "Pack အရေအတွက်ကို စစ်ပါ"
                        else -> {
                            val item = Sku(name, newSkuCategory, price, bag, carton)
                            skuList.add(item)
                            saveCustomSkus()
                            sku = item
                            notice = "SKU အသစ် ထည့်ပြီးပါပြီ"
                            showAddSkuDialog = false
                        }
                    }
                }) { Text("သိမ်းမယ်") }
            },
            dismissButton = { TextButton(onClick = { showAddSkuDialog = false }) { Text("မလုပ်တော့ပါ") } }
        )
    }

    if (editingSale != null) {
        AlertDialog(
            onDismissRequest = { editingSale = null },
            title = { Text("အရောင်းစာရင်း ပြင်ဆင်ရန်") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(editingSale!!.skuName, color = Accent, fontWeight = FontWeight.Bold)
                    OutlinedTextField(value = editSaleQty, onValueChange = { editSaleQty = it.filter(Char::isDigit) }, label = { Text("Qty") })
                    OutlinedTextField(value = editSaleAmount, onValueChange = { editSaleAmount = it.filter(Char::isDigit) }, label = { Text("Amount (ကျပ်)") })
                }
            },
            confirmButton = { TextButton(onClick = {
                val old = editingSale!!; val q = editSaleQty.toIntOrNull() ?: 0; val a = editSaleAmount.toLongOrNull() ?: 0L
                if (q > 0 && a > 0L) scope.launch { dao.update(old.copy(receiptQuantity = q, packQuantity = q, amountMmk = a, unitPriceMmk = a / q)); editingSale = null; notice = "အရောင်းစာရင်း ပြင်ပြီးပါပြီ" }
                else notice = "Qty နဲ့ Amount မှန်ကန်စွာ ဖြည့်ပါ"
            }) { Text("သိမ်းမယ်") } },
            dismissButton = { TextButton(onClick = { editingSale = null }) { Text("မလုပ်တော့ပါ") } }
        )
    }
    if (deleteSale != null) {
        AlertDialog(
            onDismissRequest = { deleteSale = null },
            title = { Text("အရောင်းစာရင်း ဖျက်မလား") },
            text = { Text("${deleteSale!!.skuName} • ${deleteSale!!.amountMmk.mmk()} ကို ဖျက်မှာ သေချာပါသလား။") },
            confirmButton = { TextButton(onClick = { val id = deleteSale!!.id; scope.launch { dao.deleteById(id); deleteSale = null; notice = "အရောင်းစာရင်း ဖျက်ပြီးပါပြီ" } }) { Text("ဖျက်မယ်", color = Color(0xFFB3261E)) } },
            dismissButton = { TextButton(onClick = { deleteSale = null }) { Text("မဖျက်တော့ပါ") } }
        )
    }

    if (showOwnerPinDialog) {
        AlertDialog(
            onDismissRequest = { showOwnerPinDialog = false; ownerPinEntry = "" },
            title = { Text("Owner PIN ထည့်ပါ") },
            text = {
                OutlinedTextField(
                    value = ownerPinEntry,
                    onValueChange = { ownerPinEntry = it.filter(Char::isDigit).take(6) },
                    label = { Text("၆ လုံး PIN") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (ownerPinEntry == "148352") {
                        ownerPriceUnlocked = true
                        notice = "Owner Price Management ဖွင့်ပြီးပါပြီ"
                        showOwnerPinDialog = false
                        ownerPinEntry = ""
                    } else {
                        notice = "Owner PIN မမှန်ပါ"
                        ownerPinEntry = ""
                    }
                }) { Text("ဝင်မယ်") }
            },
            dismissButton = {
                TextButton(onClick = { showOwnerPinDialog = false; ownerPinEntry = "" }) { Text("မလုပ်တော့ပါ") }
            }
        )
    }

    editingSku?.let { product ->
        AlertDialog(
            onDismissRequest = { editingSku = null },
            title = { Text("ဈေးနှုန်းပြင်ရန်") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(product.name, color = Muted)
                    OutlinedTextField(
                        value = editedPriceText,
                        onValueChange = { editedPriceText = it.filter(Char::isDigit).take(12) },
                        label = { Text("တစ်ထုပ်ဈေးနှုန်း (ကျပ်)") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val newPrice = editedPriceText.toLongOrNull()
                    if (newPrice != null && newPrice > 0L) {
                        priceOverrides[product.name] = newPrice
                        pricePrefs.edit().putLong(product.name, newPrice).apply()
                        notice = "${product.name} ဈေးနှုန်း ပြင်ဆင်ပြီးပါပြီ"
                        editingSku = null
                    }
                }) { Text("သိမ်းမယ်") }
            },
            dismissButton = {
                TextButton(onClick = { editingSku = null }) { Text("မလုပ်တော့ပါ") }
            }
        )
    }
}

@Composable private fun SurfaceCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFDCE6F2), RoundedCornerShape(20.dp)),
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(13.dp), content = content)
    }
}
@Composable private fun MetricCard(
    title: String,
    value: String,
    caption: String,
    modifier: Modifier = Modifier,
    cardColor: Color = Panel,
    valueColor: Color = Accent
) {
    val shape = RoundedCornerShape(30.dp)
    val bottom = when (cardColor) {
        DailyBright -> Color(0xFF0788F4)
        MonthlyBright -> Color(0xFF9B35E8)
        else -> Color(0xFF79BFFF)
    }
    Box(
        modifier = modifier.height(164.dp)
            .shadow(12.dp, shape, ambientColor = cardColor.copy(alpha = 0.32f), spotColor = Color(0x99001855))
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFFF4FDFF), cardColor.copy(alpha = 0.72f), bottom)))
            .border(2.dp, Brush.verticalGradient(listOf(Color.White, Color(0xFFD9F5FF), Color.White.copy(alpha = 0.82f))), shape)
            .drawBehind {
                // glossy top reflection and soft glass streak
                drawRoundRect(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.52f), Color.White.copy(alpha = 0.02f))),
                    topLeft = Offset(size.width * 0.07f, size.height * 0.07f),
                    size = androidx.compose.ui.geometry.Size(size.width * 0.86f, size.height * 0.22f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(size.height * 0.12f))
            }
            .padding(16.dp)
    ) {
        val saturated = cardColor == DailyBright || cardColor == MonthlyBright
        val titleInk = if (saturated) Color.White else Color(0xFF164B87)
        val valueInk = if (saturated) Color.White else Color(0xFF083D83)
        val captionInk = if (saturated) Color(0xFFF1F7FF) else Color(0xFF285B8A)
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text(title, color = titleInk, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Black)
            Text(value, color = valueInk, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black, maxLines = 2)
            Text(caption, color = captionInk, style = MaterialTheme.typography.bodySmall, maxLines = 3)
        }
    }
}
@Composable private fun AchievementCard(
    actual: Long,
    target: Long,
    remaining: Long,
    percent: Double,
    progress: Float
) {
    val shape = RoundedCornerShape(28.dp)
    Column(
        Modifier.fillMaxWidth()
            .shadow(12.dp, shape, ambientColor = Color(0x667BCBFF), spotColor = Color(0xCC00164A))
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFFFFF8FF), Color(0xFFE8DCFF), Color(0xFFB8D9FF))))
            .border(2.dp, Color.White, shape)
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("MONTHLY TARGET ACHIEVEMENT", color = Color(0xFF243E83), fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleSmall)
            Text("${"%.1f".format(java.util.Locale.US, percent)}%", color = Color(0xFF4D20A8), fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
        }
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier.fillMaxWidth().height(13.dp).clip(RoundedCornerShape(20.dp)),
            color = Color(0xFF20C76A),
            trackColor = Color(0xFFD4C8F0)
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text("ACTUAL SALES", color = Color(0xFF526A91), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                Text(actual.mmk(), color = Color(0xFF123F83), fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
            }
            Column(Modifier.weight(1f)) {
                Text("MONTHLY TARGET", color = Color(0xFF526A91), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                Text(target.mmk(), color = Color(0xFF123F83), fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
            }
        }
        Text(
            if (remaining == 0L) "Target ပြည့်မီပါပြီ 🎉" else "Target ပြည့်ရန် ကျန်ငွေ ${remaining.mmk()}",
            color = Color(0xFF263E78), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium
        )
    }
}

@Composable private fun SectionTitle(text: String) {
    Row(Modifier.fillMaxWidth().padding(top = 3.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
        Box(Modifier.width(4.dp).height(22.dp).background(Accent, RoundedCornerShape(4.dp)))
        Text(text, color = Color.White, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
    }
}
@Composable private fun InfoCard(text: String) { SurfaceCard { Text(text, color = Muted) } }
@Composable private fun ActionCard(icon: String, label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(27.dp)
    Row(
        modifier = modifier.heightIn(min = 78.dp)
            .shadow(10.dp, shape, ambientColor = Color(0x5572CFFF), spotColor = Color(0xCC00164A))
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFFFFFEFF), Color(0xFFE7F6FF), Color(0xFF8CCBFF))))
            .border(2.dp, Color.White, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(11.dp)
    ) {
        Box(Modifier.size(48.dp).shadow(5.dp, RoundedCornerShape(18.dp)).clip(RoundedCornerShape(18.dp))
            .background(Brush.verticalGradient(listOf(Color.White, Color(0xFFE9DFFF), Color(0xFFB7DFFF))))
            .border(1.5.dp, Color.White, RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
            Text(icon, color = Color(0xFF1264B4), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
        }
        Text(label, color = Color(0xFF123B70), fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.bodyMedium)
    }
}
@Composable private fun SaleCard(name: String, qty: String, amount: String, date: String) {
    Card(
        modifier = Modifier.fillMaxWidth().shadow(9.dp, RoundedCornerShape(24.dp)).border(2.dp, Color.White, RoundedCornerShape(24.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F7FF)), shape = RoundedCornerShape(24.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 5.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(name, color = Ink, fontWeight = FontWeight.Bold)
                Text(qty, color = Muted, style = MaterialTheme.typography.bodySmall)
                Text(date, color = Muted, style = MaterialTheme.typography.labelSmall)
            }
            Text(amount, color = Accent, fontWeight = FontWeight.ExtraBold)
        }
    }
}
