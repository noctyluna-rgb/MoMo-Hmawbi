package com.momo.mahwbi

enum class Category(val label: String) {
    SANITARY("Sanitary"),
    BABY_DIAPER("Baby Diaper"),
    ADULT("Adult"),
    WET_TISSUE("Wet"),
    DRY_TISSUE("Dry"),
    OTHER("Other")
}

enum class ReceiptUnit { PACK, BAG, CARTON }

data class Sku(
    val name: String,
    val category: Category,
    val pricePerPack: Long,
    val packsPerBag: Int = 1,
    val packsPerCarton: Int = 1,
    val receiptUnit: ReceiptUnit = ReceiptUnit.PACK
) {
    fun toPacks(quantity: Int, unit: ReceiptUnit): Int = when (unit) {
        ReceiptUnit.PACK -> quantity
        ReceiptUnit.BAG -> quantity * packsPerBag
        ReceiptUnit.CARTON -> quantity * packsPerCarton
    }
}

object SkuMaster {
    // Prices are MMK per individual pack. Pack conversions are applied only
    // when the receipt quantity unit is explicitly BAG or CARTON.
    val all: List<Sku> = listOf(
        // Baby Diaper — Pull သေး sizes are grouped; NB remains a separate SKU
        Sku("Pull သေး", Category.BABY_DIAPER, 7000, packsPerBag = 16),
        Sku("Pull 1 NB", Category.BABY_DIAPER, 5400, packsPerBag = 16),
        Sku("Wasuka", Category.BABY_DIAPER, 30000, packsPerBag = 6),
        Sku("Wasuka Mini", Category.BABY_DIAPER, 6200, packsPerBag = 16),
        Sku("Pull Gyi", Category.BABY_DIAPER, 15500, packsPerCarton = 8),
        Sku("Royal Baby", Category.BABY_DIAPER, 6100, packsPerCarton = 16),

        // Adult Diaper
        Sku("Comfree Pull", Category.ADULT, 17300, packsPerBag = 10),
        Sku("Comfree Diaper M", Category.ADULT, 20000, packsPerBag = 8),
        Sku("Comfree Diaper L", Category.ADULT, 22000, packsPerBag = 8),
        Sku("Comfree Diaper XL", Category.ADULT, 24000, packsPerBag = 8),
        Sku("Comfree Diaper 2XL", Category.ADULT, 26000, packsPerBag = 8),

        // Sanitary
        Sku("Blue 423", Category.SANITARY, 1800, packsPerBag = 50),
        Sku("Blue 409", Category.SANITARY, 2400, packsPerBag = 50),
        Sku("Lady Pants", Category.SANITARY, 4500, packsPerBag = 36),
        Sku("Baby Mother Pad", Category.SANITARY, 12000, packsPerBag = 48),
        Sku("Under Pad", Category.ADULT, 15000, packsPerBag = 10),
        Sku("Daily718", Category.SANITARY, 1500, packsPerCarton = 120),
        Sku("Daily728", Category.SANITARY, 1650, packsPerCarton = 120),

        // Wet Tissue
        Sku("Baby Boss Wet Tissue", Category.WET_TISSUE, 1850, packsPerCarton = 36),
        Sku("Lovely Baby Wet Tissue", Category.WET_TISSUE, 2500, packsPerCarton = 30),

        // Dry Tissue
        Sku("Dima", Category.DRY_TISSUE, 1500, packsPerBag = 100),
        Sku("Dima Classic", Category.DRY_TISSUE, 2080, packsPerBag = 100)
    )

    fun findByName(name: String): Sku? =
        all.firstOrNull { it.name.equals(name.trim(), ignoreCase = true) }
}

data class SalesLine(
    val sku: Sku,
    val receiptQuantity: Int,
    val receiptUnit: ReceiptUnit
) {
    val packQuantity: Int get() = sku.toPacks(receiptQuantity, receiptUnit)
    val amountMmk: Long get() = packQuantity.toLong() * sku.pricePerPack
}

data class CategoryAmount(val category: Category, val amountMmk: Long)

object SalesCalculator {
    fun categorySummary(lines: List<SalesLine>): List<CategoryAmount> =
        Category.entries.map { category ->
            CategoryAmount(category, lines.filter { it.sku.category == category }.sumOf { it.amountMmk })
        }

    fun skuSummary(lines: List<SalesLine>): Map<String, Pair<Int, Long>> =
        lines.groupBy { canonicalSkuName(it.sku.name) }.mapValues { (_, rows) ->
            rows.sumOf { it.packQuantity } to rows.sumOf { it.amountMmk }
        }

    // Normalize receipt size variants into the agreed reporting labels.
    fun canonicalSkuName(raw: String): String {
        val n = raw.trim().lowercase().replace(Regex("\\s+"), " ")
        return when {
            n == "pull 1 nb" || n == "pull nb" || n == "nb" -> "Pull 1 NB"
            n.startsWith("pull 1") || n == "pull သေး" -> "Pull သေး"
            n.startsWith("comfree pull") -> "Comfree Pull"
            else -> raw.trim()
        }
    }
}
