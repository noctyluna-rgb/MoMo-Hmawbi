package com.momo.mahwbi

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Update
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "sales_lines")
data class SaleLineEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val skuName: String,
    val category: String,
    val receiptQuantity: Int,
    val receiptUnit: String,
    val packQuantity: Int,
    val unitPriceMmk: Long,
    val amountMmk: Long,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface SalesDao {
    @Insert suspend fun insert(line: SaleLineEntity)
    @Insert suspend fun insertAll(lines: List<SaleLineEntity>)
    @Update suspend fun update(line: SaleLineEntity)
    @Query("DELETE FROM sales_lines WHERE id = :id") suspend fun deleteById(id: Long)
    @Query("SELECT * FROM sales_lines ORDER BY createdAt DESC, id DESC")
    fun observeAll(): Flow<List<SaleLineEntity>>
    @Query("SELECT * FROM sales_lines ORDER BY createdAt DESC, id DESC") suspend fun getAll(): List<SaleLineEntity>
    @Query("DELETE FROM sales_lines")
    suspend fun deleteAll()
}

@Database(entities = [SaleLineEntity::class], version = 1, exportSchema = false)
abstract class MoMoDatabase : RoomDatabase() {
    abstract fun salesDao(): SalesDao

    companion object {
        @Volatile private var INSTANCE: MoMoDatabase? = null
        fun get(context: Context): MoMoDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    MoMoDatabase::class.java,
                    "momo_sales.db"
                ).build().also { INSTANCE = it }
            }
    }
}
