# Backup / Restore အသုံးပြုပုံ (v1.2.0)

1. Settings > BACKUP / RESTORE ကိုဖွင့်ပါ။
2. `Backup သိမ်းမယ်` ကိုနှိပ်ပြီး ဖိုင်အမည် `MoMo_Hmawbi_Backup.zip` ကို သိမ်းပါ။
3. Backup ZIP ကို ဖုန်းပြင်ပနေရာ (Google Drive သို့မဟုတ် အခြားလုံခြုံသောနေရာ) ထပ်မံကူးထားပါ။
4. Restore လုပ်ရန် `Backup Restore လုပ်မယ်` ကိုနှိပ်ပြီး MoMo Backup ZIP ကိုရွေးပါ။
5. Restore သည် လက်ရှိအရောင်းစာရင်းနှင့် ဆက်တင်များကို Backup ထဲရှိအချက်အလက်များဖြင့် အစားထိုးသည်။ ထို့ကြောင့် Restore မလုပ်မီ လက်ရှိအခြေအနေကို Backup အရင်သိမ်းပါ။

ဓာတ်ပုံဖိုင်များပါဝင်သော ZIP Backup v2 ကိုသာ ဤ version တွင် restore လုပ်နိုင်သည်။ ယခင် JSON backup များကို မဖျက်ပါနှင့်။
