# GitHub မှ APK Build လုပ်ရန် (ဖုန်းဖြင့်)

1. ZIP ကို Extract လုပ်ပါ။ Extract လုပ်ပြီးရလာသော project အတွင်းရှိ ဖိုင်/ဖိုလ်ဒါအားလုံးကို GitHub repository ၏ root ထဲသို့ တင်ပါ။ ZIP ဖိုင်တစ်ခုတည်းကို repository ထဲတင်ခြင်း မလုပ်ပါနှင့်။
2. Repository ၏ `Actions` tab ကိုဖွင့်ပါ။ ပထမဆုံးအကြိမ် workflow enable လုပ်ရန် မေးလာလျှင် enable လုပ်ပါ။
3. `Build Mo Mo Hmawbi APK` workflow ကိုရွေးပြီး `Run workflow` ကိုနှိပ်ပါ။ `main` (သို့) `master` branch ကိုရွေးပြီး Run workflow ကို ထပ်နှိပ်ပါ။
4. အလုပ်ပြီးလျှင် အစိမ်းရောင် ✓ ဖြစ်လာမည်။ Run တစ်ခုကိုဖွင့်ပြီး အောက်ဆုံး `Artifacts` မှ `MoMo-Hmawbi-v1.0.6-debug-apk` ကိုနှိပ်၍ download လုပ်ပါ။
5. ZIP အဖြစ်ရလာသော artifact ကို ဖုန်းထဲ Extract လုပ်ပြီး `app-debug.apk` ကိုနှိပ်ကာ Install လုပ်ပါ။ Android မေးလျှင် browser/files app အတွက် Install unknown apps ခွင့်ပြုပါ။

Build မအောင်မြင်လျှင် Actions run එකේ error log/screenshot ပို့ပါ။

## v1.0.5 Dashboard Update
Dashboard မှာ Total Sale ကို အစိမ်းနု၊ Monthly Sales ကို Target 80% မပြည့်မချင်း အနီနု၊ 80% ပြည့်တာနဲ့ အစိမ်းနု ပြောင်းထားပါတယ်။ Monthly Achievement % နဲ့ Target ကိုပါ ပြပေးပါတယ်။ Target 1,700 သိန်း = 170,000,000 ကျပ် ဖြစ်ပါတယ်။


## v1.0.6 Map
Customer Map ကို drawer menu မှ ဝင်နိုင်သည်။ GPS permission ကို ပထမဆုံးအသုံးပြုချိန်တွင် Allow လုပ်ပါ။ Customer Pin ထည့်ရန် ဆိုင်အမည်၊ Latitude၊ Longitude ဖြည့်ပြီး သိမ်းပါ။ Route ခလုတ်သည် ဖုန်းရှိ navigation app ကိုဖွင့်ပေးသည်။
