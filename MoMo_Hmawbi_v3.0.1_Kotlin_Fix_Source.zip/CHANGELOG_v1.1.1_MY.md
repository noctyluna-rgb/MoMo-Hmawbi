# MoMo (Hmawbi) v1.1.1

- Settings ထဲက “Developed by Phyo Thet Htun 🇲🇲” အောက်ရှိ “ခွေးလေးကို ကြည့်ရန် နှိပ်ပါ 🐶” စာသားကို ဖယ်ရှားထားသည်။
- Developer အမည်ကိုနှိပ်လျှင် Puppy Popup ပွင့်နေမည်။
- Puppy Popup အတွင်းရှိ ချစ်စရာစာသားကို မဖယ်ရှားထားပါ။
- Permanent Release Signing configuration ကို ဆက်ထိန်းထားသည်။
- versionName 1.1.1, versionCode 29.
