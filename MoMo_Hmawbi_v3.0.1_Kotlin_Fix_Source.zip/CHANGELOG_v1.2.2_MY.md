# MoMo Hmawbi v1.2.2

## OCR Amount auto calculation (editable)
- Amount is automatically calculated as Qty × Price when Qty or Price changes.
- Amount remains an editable field so the user can correct small differences against the receipt.
- Saving uses the final value in the Amount field, including any manual correction.
- Overflow is handled safely; an invalid/overflowing calculation leaves Amount blank for manual review.

Version: 1.2.2
Version code: 32
