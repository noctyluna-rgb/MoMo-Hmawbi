# MoMo (Hmawbi) v1.2.0

- Version name 1.2.0, versionCode 30.
- Settings ရှိ Backup/Restore ကို ZIP ဖိုင်ပုံစံသို့ အဆင့်မြှင့်ထားသည်။
- အရောင်းစာရင်းနှင့် SharedPreferences ဆက်တင်များကို backup ထဲထည့်သည်။
- SKU ထုတ်ကုန်ဓာတ်ပုံများ၏ ဖိုင်အမှန်များကို `photos/` entries အဖြစ် ZIP ထဲထည့်သည်။
- Restore မလုပ်မီ ZIP ဖွဲ့စည်းပုံ၊ manifest နှင့် ဓာတ်ပုံ entry များကို စစ်ဆေးသည်။
- Restore အတွင်း DB transaction အသုံးပြုပြီး preferences ပြောင်းလဲမှုမအောင်မြင်လျှင် မူလ DB/preferences များကို ပြန်ထားရန် ကြိုးစားသည်။
- Puppy Popup ဖယ်ရှားခြင်း/Developer စာသားပြင်ဆင်မှုနှင့် permanent release signing configuration ကို ဆက်ထိန်းထားသည်။

## သတိပြုရန်

- ယခင် JSON backup v1 ကို ဤ version ၏ ZIP importer မှ တိုက်ရိုက် restore မလုပ်နိုင်သေးပါ။ ယခင် JSON ဖိုင်များကို မဖျက်ဘဲ သိမ်းထားပါ။
- External content URI များကို Backup လုပ်ချိန်တွင် ဖတ်ခွင့်မရပါက Backup ကို error ဖြင့် ရပ်တန့်မည်။
- Restore စမ်းသပ်မှု၊ Android device test နှင့် Gradle release build ကို GitHub Actions တွင် အတည်ပြုရန် လိုသေးသည်။
