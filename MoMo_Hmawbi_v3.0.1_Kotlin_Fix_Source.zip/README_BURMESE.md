# MoMo(Hmawbi) Android Starter

ဤ ZIP သည် Android Studio ဖြင့် ဆက်လက်တည်ဆောက်ရန် Kotlin/Jetpack Compose source project ဖြစ်ပြီး **APK မဟုတ်သေးပါ**။

ပါဝင်သည်:
- Android Home Screen
- Gallery မှ ဘောင်ချာ Screenshot အများအပြားရွေးချယ်ခြင်း
- ML Kit On-device OCR ဖြင့် စာသားဖတ်ခြင်း
- SKU Summary / Category Summary / Daily Report အတွက် အခြေခံ Screen

နောက်တစ်ဆင့်များ:
1. OCR စာသားမှ ဘောင်ချာ row/column များကို ခွဲထုတ်ခြင်း။
2. သတ်မှတ်ထားသော SKU Master၊ ဈေးနှုန်း၊ pack conversion ထည့်ခြင်း။
3. Room Database ဖြင့် Offline သိမ်းခြင်း။
4. Firebase Auth/Cloud Backup/Sync ချိတ်ဆက်ခြင်း။
5. Unknown SKU နှင့် OCR မသေချာမှုများကို အတည်ပြုခိုင်းခြင်း။

လိုအပ်ချက်: Android Studio, JDK 17, Android SDK 35။ Android Studio မှ project ဖွင့်ပြီး Gradle Sync လုပ်ပါ။ Firebase ချိတ်ဆက်မှုနှင့် APK build ကို နောက်အဆင့်တွင် ပြီးစီးအောင်လုပ်ရမည်။


## ထပ်မံထည့်သွင်းပြီးသော SKU Master
- သဘောတူထားသော SKU ၁၆ မျိုး၊ Category၊ MMK ဈေးနှုန်းနှင့် Bag/Carton conversion များကို Kotlin master အဖြစ် ထည့်ထားသည်။
- PACK / BAG / CARTON ကို သီးခြားသတ်မှတ်ထားပြီး BAG/CARTON ပြောင်းလဲမှုကို ဘောင်ချာယူနစ် အတည်ပြုမှသာ သုံးသည်။
- SKU Summary နှင့် Category Summary အတွက် calculation engine ထည့်ထားသည်။
- မသိသော SKU ကို အလိုအလျောက် အမျိုးအစား/ဈေးနှုန်း ခန့်မှန်းမည်မဟုတ်ပါ။

မှတ်ချက်: လက်ရှိအဆင့်တွင် OCR သည် ပုံမှစာသားထုတ်ယူပေးခြင်းသာ ဖြစ်သည်။ ထုတ်ယူထားသောစာသားကို SKU/Qty/ယူနစ်အဖြစ် အပြည့်အဝခွဲခြားခြင်း၊ Room database နှင့် Firebase Sync တို့ကို နောက်ထပ်အဆင့်များတွင် ဆက်တည်ဆောက်ရမည်။


## Version 3 – Offline database & manual entry
- Room Database (`momo_sales.db`) ဖြင့် ဖုန်းထဲမှာ အရောင်းလိုင်းများ သိမ်းသည်။
- SKU ရွေးခြင်း၊ Qty နှင့် Pack/Bag/Carton ယူနစ်ရွေးခြင်း၊ Amount အလိုအလျောက်တွက်ခြင်း ပါဝင်သည်။
- Category Summary ကို သိမ်းထားသောစာရင်းမှ ပြန်တွက်သည်။
- Screenshot OCR သည် စာသားဖတ်ပြနိုင်သော်လည်း receipt layout parsing/auto-import မပြီးသေးပါ။
- Firebase Cloud Backup/Sync မချိတ်ဆက်ရသေးပါ။


## Version 4 – Report calculations
- Kotlin 2.x အတွက် Compose compiler plugin configuration ကို ပြင်ဆင်ထားသည်။
- Daily / Weekly (Monday မှ Sunday) / Monthly report ကို ဖုန်းရဲ့ local date အလိုက်တွက်သည်။
- ကာလတစ်ခုချင်းစီအတွက် Category Summary နှင့် SKU Summary ကို ပြသည်။
- Qty ကို SKU တစ်မျိုးချင်းစီအလိုက်သာ ပြသည်။ မတူသော SKU Qty များကို စုစုပေါင်းမပေါင်းပါ။
- အရေးကြီး: Weekly/Monthly Actual များသည် လက်ရှိ local database ထဲက စာရင်းများမှ တွက်ထားသည်။ ယခင် spreadsheet ထဲက လက်ကျန်တန်ဖိုးများကို အလိုအလျောက် မယူသေးပါ။


## Version 0.6.0 — ဈေးနှုန်းပြင်ဆင်ခြင်း
- Product & Price စာမျက်နှာတွင် SKU တစ်ခုချင်းစီ၏ တစ်ထုပ်ဈေးနှုန်းကို ပြင်ဆင်နိုင်သည်။
- ပြင်ထားသောဈေးနှုန်းကို Android SharedPreferences ဖြင့် ဖုန်းထဲတွင် သိမ်းထားသည်။
- နောက်ထပ် အရောင်းအသစ်များတွင် ပြင်ထားသောဈေးနှုန်းကို အသုံးပြုသည်။ ယခင်အရောင်းမှတ်တမ်းများကို မပြောင်းပါ။
- ဈေးနှုန်းပြောင်းလဲမှုများသည် လက်ရှိဖုန်းပေါ်တွင်သာ သိမ်းထားပြီး Cloud Sync မပါသေးပါ။
\n\n## Version 0.8.0\n- Owner PIN ဖြင့် Settings မှ SKU အသစ်ထည့်နိုင်သည်။\n- SKU အမည်၊ Category၊ တစ်ထုပ်ဈေးနှုန်း၊ Bag နှင့် Carton conversion ကို သတ်မှတ်နိုင်သည်။\n- Custom SKU များကို ဖုန်း၏ SharedPreferences တွင် သိမ်းထားသည်။\n- Firebase cloud sync မပါသေးပါ။\n

## App Display Name
- Launcher နှင့် App Header အမည်ကို `MoMo(Hmawbi)` ဟု ပြောင်းထားသည်။


## Launcher Icon
- User ပေးထားသော HB logo ကို Home Screen App Icon အဖြစ် ထည့်ထားသည်။


## Version 0.8.3 — Product Photos
- Product & Price စာမျက်နှာတွင် SKU တစ်ခုချင်းစီအတွက် Gallery မှ ပုံရွေးထည့်နိုင်သည်။
- ရွေးထားသောပုံ URI ကို ဖုန်း၏ local preferences တွင် သိမ်းထားသည်။
- ပုံပြောင်းခြင်းနှင့် ပုံဖျက်ခြင်း ပါဝင်သည်။
- ဤဗားရှင်းတွင် Product ပုံများကို Firebase သို့ မတင်သေးပါ။ ဖုန်းတစ်လုံးချင်းစီတွင်သာ ရှိနေမည်။


## Version 0.9.0 — Premium Business Catalog Update
- Premium Business Navy Blue + Gold + White palette.
- SKU master prices updated to the latest user-provided MMK prices.
- Added Pull Gyi, Royal Baby, Daily718, Daily728 with only confirmed carton conversions.
- Pull 1 (NB) removed from active master and merged into Pull 1.
- Product page has SKU add action, price edit entry and custom SKU remove action.
- Back arrow and Android system Back navigation return to the previous page.
- Product photo picker remains available; photos remain local to this device only.
- Important: this source update has not been independently Gradle-built or device-tested here. SKU deletion currently removes custom SKUs from the active list; historical-sale archive protection and Firebase sync still require implementation and verification.


## Version 1.0.0 — Smart Sales groundwork
- Pull သေး (Pull 1 S/M/L/XL စသည်) ကို SKU Summary တွင် တစ်မျိုးတည်း စုစည်းသည်။
- Pull 1 NB ကို သီးခြား SKU အဖြစ် ထားသည်။
- Comfree Pull ကို Adult category အောက်တွင် ထားပြီး size variant များကို SKU Summary တွင် Comfree Pull အဖြစ် စုစည်းသည်။
- Comfree Diaper size SKU များကို Adult category အောက်တွင် ထားသည်။
- OCR သည် ယခုအဆင့်တွင် စာသားဖတ်ယူနိုင်ဆဲဖြစ်ပြီး OCR မှ SKU/Qty/Amount အလိုအလျောက်အတည်ပြုသိမ်းဆည်းခြင်းနှင့် duplicate receipt detection ကို မပြီးသေးပါ။
- APK build/device test မလုပ်ရသေးပါ။

## Version 1.0.2 — Clean White Blue Theme
- App theme updated from Premium Dark to Clean White Blue.
- Background uses a soft off-white, cards use white, selected surfaces use pale blue, and primary actions/highlights use blue.
- Text colors updated for contrast on light surfaces.
- Version: 1.0.2 (versionCode 15).


## v1.0.4 ပြင်ဆင်ချက်
- OCR Review တွင် SKU / Qty / Amount ကို သီးခြားစစ်ဆေးနိုင်ပြီး ဘောင်ချာ Qty နှင့် Amount အတိုင်း သိမ်းနိုင်သည်။
- OCR Review စာရင်းကို SKU / Qty / Amount ပုံစံဖြင့် Copy ကူးနိုင်သည်။
- Sales History မှ ရောင်းချပြီးသား record တစ်ကြောင်းချင်း ပြင်ဆင် / ဖျက်နိုင်သည်။
- Sales History LazyColumn တွင် stable record key သတ်မှတ်ထားသည်။
- GitHub Actions ဖြင့် APK build လုပ်ရန် လိုအပ်သည်။ ဤ Source ZIP ကို APK အဖြစ် စမ်းသပ်အောင်မြင်ပြီးပြီဟု မဆိုလိုပါ။

## Version 1.0.5 Dashboard Theme Update
- Total Sale card uses a light-green background.
- Monthly Sales card uses a light-red background until achievement reaches 80%.
- At 80% achievement or higher, Monthly Sales card changes to light green.
- Monthly target is 1,700 သိန်း = 170,000,000 ကျပ်.
- Dashboard shows monthly achievement percentage and target amount.

## v1.0.6 Customer Map (MVP)
- Customer Map page ထည့်ထားပြီး မှော်ဘီ (17.072, 96.067) ကို ဗဟိုထားသော 50 km အဝိုင်းပြထားသည်။
- OpenStreetMap အခြေခံမြေပုံ၊ ဖုန်း GPS တည်နေရာပြခြင်း၊ Customer ဆိုင်အမည်/Latitude/Longitude ဖြင့် Pin သိမ်းခြင်း၊ Pin ဖျက်ခြင်းနှင့် Navigation app သို့ လမ်းကြောင်းဖွင့်ခြင်း ပါဝင်သည်။
- Customer Pin များကို ဖုန်းအတွင်း SharedPreferences ဖြင့် သိမ်းထားသည်။
- မြေပုံကြည့်ထားသော Tile များကို OSMDroid cache ထဲတွင် သိမ်းနိုင်သော်လည်း 50 km တစ်ခုလုံးကို Offline bulk-download လုပ်သည့် feature မပါသေးပါ။ Public OpenStreetMap tile server များကို bulk download လုပ်ရန် မသုံးထားပါ။ Offline routing ကိုလည်း သီးခြား data/provider လိုအပ်သဖြင့် မပါသေးပါ။


## v1.0.6 — Google Sheets Actual Copy
- Sales Reports တွင် Monthly Actual Copy နှင့် Daily Actual Copy ခလုတ်များ ထည့်ထားသည်။
- ခလုတ်တစ်ခုစီသည် Category အစဉ်အတိုင်း (Sanitary, Baby Diaper, Adult, Wet Tissue, Dry Tissue) ကျပ်ငွေ ၅ ကြောင်းကို tab မပါဘဲ newline ခွဲ၍ Clipboard သို့ကူးပေးသည်။
- Google Sheets တွင် သက်ဆိုင်ရာ Actual column ၏ ပထမ Category cell ကိုရွေးပြီး Paste လုပ်နိုင်သည်။


## Version 3.0.0 — Monthly Program & Dashboard Refresh
- Monthly Target သိန်း ၁,၇၀၀ ကို Category ၆ မျိုးဖြင့် ခွဲထားသည်: Sanitary 25,500,000; Baby Diaper 74,800,000; Adult 25,500,000; Wet 5,100,000; Dry 37,400,000; Other 1,700,000 MMK.
- Monthly Program စာမျက်နှာတွင် Category တစ်ခုချင်းစီ၏ Actual, Target, Remaining နှင့် Achievement ကို ပြသည်။
- Category မသတ်မှတ်ထားသော Manual Daily Amount များကို Monthly Program ၏ Other ထဲတွင် ထည့်တွက်သည်။
- Dashboard ရှိ Total Records နှင့် Mode ကတ်များကို ဖယ်ရှားပြီး Monthly Program shortcut အစားထိုးထားသည်။
- App bar တွင် Version 3.0.0 ပြထားပြီး ၃ ချက်ဆက်တိုက်နှိပ်ပါက ဆုတောင်းစာသားနှင့် animated sprites ပေါ်သည်။
- Dashboard theme ကို Dark Navy + Teal ပြောင်းထားသည်။
- Android versionCode 36 / versionName 3.0.0.
