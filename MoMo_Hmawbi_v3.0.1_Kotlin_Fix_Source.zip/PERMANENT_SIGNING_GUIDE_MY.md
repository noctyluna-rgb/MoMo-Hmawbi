# MoMo(Hmawbi) v1.1.0 — Developer Puppy Popup + Permanent Signing

ဤ Source ZIP သည် အကိုပေးထားသော **v1.0.9 Developer Puppy Popup source** ကို အခြေခံထားသည်။
Developer Puppy Popup နှင့် အခြား app source များကို မဖယ်ရှားဘဲ Android version ကို 1.1.0 / versionCode 28 သို့ မြှင့်ထားသည်။

## GitHub Actions Secrets
Repository → Settings → Secrets and variables → Actions ထဲတွင် အောက်ပါ repository secrets ၄ ခု ရှိရမည်။
- `RELEASE_KEYSTORE_BASE64`
- `RELEASE_STORE_PASSWORD`
- `RELEASE_KEY_ALIAS`
- `RELEASE_KEY_PASSWORD`

အကို အရင်ထည့်ထားသော permanent keystore နှင့် ကိုက်ညီသည့် secret values များကိုပဲ ဆက်သုံးပါ။ Keystore အသစ် မထုတ်ပါနှင့်၊ secret values မပြောင်းပါနှင့်။

## Build
GitHub → Actions → Build MoMo Hmawbi Signed Release APK → Run workflow။
အောင်မြင်လျှင် Artifacts မှ `MoMo-Hmawbi-v1.1.0-Permanent-Signed` ကို download လုပ်ပါ။

## Update compatibility
- applicationId: `com.momo.mahwbi` (မပြောင်းထားပါ)
- versionName: `1.1.0`
- versionCode: `28`
- Build type: release, permanent keystore ဖြင့် sign

ဤ ZIP ကို ပြင်ဆင်ထားခြင်းသာ ဖြစ်ပြီး GitHub Actions build ကို မလုပ်ရသေးပါ။ Build အောင်မြင်မှ APK ထုတ်ပေးပါမည်။
