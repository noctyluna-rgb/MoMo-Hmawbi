# MoMo(Hmawbi) v3.0.0 — Monthly Program & Dashboard Refresh

- Updated monthly category targets:
  - Sanitary: 25,500,000 MMK
  - Baby Diaper: 74,800,000 MMK
  - Adult: 25,500,000 MMK
  - Wet: 5,100,000 MMK
  - Dry: 37,400,000 MMK
  - Other: 1,700,000 MMK
- Category targets total exactly 170,000,000 MMK (1,700 lakhs).
- Added Monthly Program screen with per-category actual sales, target, remaining amount, and achievement progress.
- Manual daily amounts with no SKU/category attribution are included under Other in Monthly Program.
- Removed Total Records and Mode dashboard cards; replaced them with a Monthly Program shortcut.
- Replaced Dashboard subtitle in the app bar with Version 3.0.0. Tapping the version three times quickly opens the animated Burmese wish message.
- Refreshed dashboard cards to a dark navy and teal glass-style theme.
- Increased Android versionCode to 36 and versionName to 3.0.0.

Build note: this source ZIP is a Gradle project; it is not a prebuilt APK. The uploaded source has not been compiled or device-tested in this environment.
