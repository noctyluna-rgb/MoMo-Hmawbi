# SKU Master (MMK)

The app now contains the currently agreed SKU list, category mapping, pack prices,
and bag/carton conversions.

Important calculation rule:
- PACK quantity is kept as entered.
- BAG and CARTON conversions are applied only when the receipt's unit is explicitly selected.
- Amount = individual pack quantity × price per individual pack.
- Unknown SKUs must be held for user confirmation; never guess category, price, or conversion.
- Do not total quantities across different SKUs.

Categories (fixed order for reports):
1. Sanitary
2. Baby Diaper
3. Adult
4. Wet Tissue
5. Dry Tissue

This catalog is currently a Kotlin source master. The next implementation step is
an editable in-app SKU Master screen and persistence in Room.


## Added SKU v1.0.4
- Under Pad — Adult — 15,000 MMK per pack — 10 packs per bag. Receipt Qty remains exactly as printed on the voucher.
